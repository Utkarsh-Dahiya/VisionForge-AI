# VisionForge AI

Local computer-vision platform: YOLO object detection on images and video, with analytics.

## Run (Windows PowerShell, from the project root)

```powershell
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app/mainn.py
```

`yolo11n.pt` is looked up in the project root (or `models/`, `weights/`). If absent, Ultralytics may try to download it.

## Tests

```powershell
python -m pytest -v
# or, without pytest (only the new tests):
python -m unittest discover -s tests -p "test_ui_helpers.py" -v
python -m unittest discover -s tests -p "test_video_service.py" -v
```

## Layout

| Path | Purpose |
|---|---|
| `app/mainn.py` | Streamlit entry point, sidebar shell and all pages |
| `app/video_service.py` | Upload validation, per-run output folders, calls `VideoProcessor`, H.264 re-encode |
| `app/helpers.py`, `app/components.py`, `app/modules.py`, `app/assets/neural.css` | Pure helpers, HTML components, module status registry, theme |
| `core/detection/detection_engine.py` | YOLO image detection (unchanged) |
| `core/video/video_processor.py` | Video processing (one optional `progress_callback` argument added) |

## Video behaviour

- **Frame stride N**: detection runs on source frames 0, N, 2N, …; other frames are copied unannotated.
- Counts are **detections**, not unique objects: there is no tracking.
- OpenCV writes `mp4v`, which most browsers cannot play. If FFmpeg is found (system `ffmpeg` or `imageio-ffmpeg`),
  the app re-encodes to H.264 for the in-page player and the download. Otherwise it says so and shows a still-frame
  preview instead of pretending to play the video.
- Outputs go to `outputs/videos/<run id>/`; the previous run's folder is deleted when you analyse again or press Reset.
