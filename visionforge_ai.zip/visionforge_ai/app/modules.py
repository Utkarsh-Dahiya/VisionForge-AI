"""Single source of truth for module status (Command Center + Platform Overview).

Statuses are conservative and describe the code that exists in the project:
  Implemented - working code path wired into the UI.
  Partial     - works with stated limits.
  Planned     - no implementation yet.
Edit this file as the project evolves.
"""

APP_VERSION = "0.2.0"
APP_PHASE = "Phase 2: Image + Video Detection"

IMPLEMENTED, PARTIAL, PLANNED = "Implemented", "Partial", "Planned"

MODULES = [
    {"icon": "◈", "name": "Vision Studio", "status": IMPLEMENTED,
     "desc": "Upload an image and run YOLO object detection.",
     "detail": "Single-image inference via DetectionEngine; annotated image, table, CSV.",
     "target": "Vision Studio"},
    {"icon": "▶", "name": "Video Intelligence", "status": IMPLEMENTED,
     "desc": "Frame-by-frame YOLO detection on uploaded video.",
     "detail": "VideoProcessor: annotated MP4 + CSV. Per-frame detection only; no identity tracking.",
     "target": "Video Intelligence"},
    {"icon": "▥", "name": "Analytics", "status": PARTIAL,
     "desc": "Charts built from this session's analyses.",
     "detail": "Session-only; nothing is persisted across reloads.",
     "target": "Analytics"},
    {"icon": "◎", "name": "Object tracking", "status": PLANNED,
     "desc": "Persistent object identities across frames.",
     "detail": "Not implemented. Video counts are detections, not unique objects.", "target": None},
    {"icon": "⌗", "name": "OCR Studio", "status": PLANNED,
     "desc": "Text extraction from images.", "detail": "Not implemented.", "target": None},
    {"icon": "⬡", "name": "Safety / PPE", "status": PLANNED,
     "desc": "PPE checks and configurable safety rules.", "detail": "Not implemented.", "target": None},
    {"icon": "△", "name": "Fire & smoke", "status": PLANNED,
     "desc": "Fire and smoke detection.", "detail": "Not implemented.", "target": None},
    {"icon": "▤", "name": "Persistent storage", "status": PLANNED,
     "desc": "Database-backed analysis history.", "detail": "Not implemented.", "target": None},
]

PAGES = ["Command Center", "Vision Studio", "Video Intelligence",
         "Analytics", "Platform Overview"]
