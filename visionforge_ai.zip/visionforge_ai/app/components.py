"""Reusable HTML fragments. All dynamic text is escaped."""
from __future__ import annotations

from html import escape
from pathlib import Path

import streamlit as st

_APP = Path(__file__).resolve().parent
_CSS_CANDIDATES = (_APP / "assets" / "neural.css", _APP / "neural.css")


def inject_theme() -> None:
    css_path = next((p for p in _CSS_CANDIDATES if p.is_file()), None)
    if css_path is None:
        st.warning("Stylesheet neural.css not found; using default Streamlit styling.")
        return
    css = css_path.read_text(encoding="utf-8")
    st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)


def _html(fragment: str) -> None:
    st.markdown(fragment, unsafe_allow_html=True)


def sidebar_brand() -> None:
    _html(
        """<div class="vf-sb-brand"><span class="vf-mark">◈</span>
        <div><div class="vf-sb-name">VISION<b>FORGE</b> AI</div>
        <div class="vf-sb-sub">Visual Intelligence Platform</div></div></div>"""
    )


def sidebar_status(rows: list[tuple[str, str, str]]) -> None:
    """rows: (label, value, tone) where tone is ok | warn | idle."""
    items = "".join(
        f'<div class="vf-sb-row"><span>{escape(k)}</span>'
        f'<span class="vf-sb-val {escape(t)}"><i class="vf-dot"></i>{escape(v)}</span></div>'
        for k, v, t in rows
    )
    _html(f'<div class="vf-sb-status"><div class="vf-label">System</div>{items}</div>')


def sidebar_footer(text: str) -> None:
    _html(f'<div class="vf-sb-foot">{escape(text)}</div>')


def page_title(eyebrow: str, title: str, subtitle: str = "") -> None:
    sub = f"<p>{escape(subtitle)}</p>" if subtitle else ""
    _html(
        f"""<div class="vf-title"><div class="vf-eyebrow">{escape(eyebrow)}</div>
        <h1>{escape(title)}</h1>{sub}</div>"""
    )


def label(text: str) -> None:
    _html(f'<div class="vf-label">{escape(text)}</div>')


def stat(name: str, value: str, note: str = "") -> None:
    note_html = f'<div class="vf-stat-note">{escape(note)}</div>' if note else ""
    _html(
        f"""<div class="vf-stat"><div class="vf-stat-name">{escape(name)}</div>
        <div class="vf-stat-value">{escape(value)}</div>{note_html}</div>"""
    )


def status_badge(status: str) -> str:
    return f'<span class="vf-badge {escape(status.lower())}">{escape(status)}</span>'


def module_card(icon: str, name: str, desc: str, status: str) -> None:
    _html(
        f"""<div class="vf-module {escape(status.lower())}">
        <div class="vf-module-top"><span class="vf-icon">{escape(icon)}</span>
        {status_badge(status)}</div>
        <div class="vf-module-name">{escape(name)}</div>
        <div class="vf-module-desc">{escape(desc)}</div></div>"""
    )


def empty_state(icon: str, title: str, body: str) -> None:
    _html(
        f"""<div class="vf-empty"><div class="vf-empty-icon">{escape(icon)}</div>
        <div class="vf-empty-title">{escape(title)}</div>
        <div class="vf-empty-body">{escape(body)}</div></div>"""
    )


def viewport_bar(left: str, right: str = "") -> None:
    _html(
        f"""<div class="vf-vp-bar"><span>{escape(left)}</span>
        <span>{escape(right)}</span></div>"""
    )


def info_panel(title: str, body: str) -> None:
    _html(
        f"""<div class="vf-panel"><div class="vf-panel-title">{escape(title)}</div>
        <div class="vf-panel-body">{escape(body)}</div></div>"""
    )
