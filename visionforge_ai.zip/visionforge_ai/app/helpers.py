"""Pure, Streamlit-free helpers so they can be unit-tested without a server."""
from __future__ import annotations

import hashlib
import os
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

import cv2
import numpy as np
import pandas as pd

ALLOWED_TYPES = ["jpg", "jpeg", "png", "webp"]


def file_hash(data: bytes | memoryview) -> str:
    return hashlib.sha256(data).hexdigest()


def decode_image(data: bytes) -> np.ndarray | None:
    """Decode bytes into a BGR image, or None if the bytes are not an image."""
    if not data:
        return None
    return cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)


def to_rgb(image_bgr: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)


def encode_png(image_bgr: np.ndarray) -> bytes | None:
    ok, buf = cv2.imencode(".png", image_bgr)
    return buf.tobytes() if ok else None


@contextmanager
def temporary_image_file(image_bgr: np.ndarray) -> Iterator[Path]:
    """Write an image to a unique temp file and always delete it afterwards.

    A unique name per call avoids collisions between concurrent sessions.
    """
    fd, name = tempfile.mkstemp(prefix="visionforge_", suffix=".png")
    os.close(fd)
    path = Path(name)
    try:
        if not cv2.imwrite(str(path), image_bgr):
            raise RuntimeError("Could not prepare the input image.")
        yield path
    finally:
        path.unlink(missing_ok=True)


def detections_to_frame(detections: list[dict[str, Any]] | None) -> pd.DataFrame:
    """Build the display table from the engine's `detections` list.

    Uses only the keys the existing app already relies on: `label`, `confidence`.
    """
    columns = ["ID", "Object", "Confidence"]
    has_box = bool(detections) and any("bbox" in d for d in detections)
    if has_box:
        columns += ["x1", "y1", "x2", "y2"]
    if not detections:
        return pd.DataFrame(columns=columns)
    rows = []
    for i, d in enumerate(detections, start=1):
        row = {
            "ID": i,
            "Object": d.get("label", "unknown"),
            "Confidence": float(d.get("confidence", 0.0)),
        }
        if has_box:
            box = d.get("bbox") or {}
            row.update({k: box.get(k) for k in ("x1", "y1", "x2", "y2")})
        rows.append(row)
    return pd.DataFrame(rows, columns=columns)


def class_distribution(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return pd.DataFrame(columns=["Object", "Count"])
    return (
        frame["Object"].value_counts().rename_axis("Object").reset_index(name="Count")
    )


def summarize_analysis(
    filename: str, result: dict[str, Any], threshold: float
) -> dict[str, Any]:
    """Compact record stored in session history (no image data)."""
    frame = detections_to_frame(result.get("detections"))
    return {
        "kind": "image",
        "filename": filename,
        "threshold": threshold,
        "objects": int(result.get("object_count", len(frame))),
        "inference_ms": float(result.get("inference_time_ms", 0.0)),
        "width": int(result.get("image_width", 0)),
        "height": int(result.get("image_height", 0)),
        "mean_confidence": float(frame["Confidence"].mean()) if len(frame) else None,
        "classes": frame["Object"].tolist(),
        "confidences": frame["Confidence"].tolist(),
    }


def history_frame(history: list[dict[str, Any]]) -> pd.DataFrame:
    """Flatten every detection across the session into one frame."""
    rows = []
    for n, record in enumerate(history, start=1):
        for lbl, conf in zip(record["classes"], record["confidences"]):
            rows.append(
                {"Analysis": n, "Kind": record.get("kind", "image"),
                 "Source": record["filename"], "Object": lbl, "Confidence": conf}
            )
    return pd.DataFrame(
        rows, columns=["Analysis", "Kind", "Source", "Object", "Confidence"])


VIDEO_COLUMNS = ["frame", "timestamp_seconds", "class_id", "label",
                 "confidence", "x1", "y1", "x2", "y2"]


def video_records_frame(result: dict[str, Any]) -> pd.DataFrame:
    """Frame-level detection records exactly as the VideoProcessor returns them."""
    return pd.DataFrame(result.get("detections") or [], columns=VIDEO_COLUMNS)


def summarize_video(
    filename: str, result: dict[str, Any], threshold: float,
    frame_stride: int, max_frames: int | None,
) -> dict[str, Any]:
    """Compact session-history record for a video analysis."""
    frame = video_records_frame(result)
    return {
        "kind": "video",
        "filename": filename,
        "threshold": threshold,
        "frame_stride": frame_stride,
        "max_frames": max_frames,
        "objects": int(result["total_detections"]),
        "frames_read": int(result["frames_read"]),
        "frames_processed": int(result["frames_processed"]),
        "processing_seconds": float(result["processing_time_seconds"]),
        "inference_ms": float(result["processing_time_seconds"]) * 1000.0,
        "width": int(result["video_width"]),
        "height": int(result["video_height"]),
        "mean_confidence": float(frame["confidence"].mean()) if len(frame) else None,
        "classes": frame["label"].tolist(),
        "confidences": frame["confidence"].tolist(),
    }


def detections_per_frame(frame: pd.DataFrame) -> pd.DataFrame:
    """Detections per processed source frame (only frames that had >=1 detection)."""
    if frame.empty:
        return pd.DataFrame(columns=["timestamp_seconds", "Detections"])
    grouped = (frame.groupby(["frame", "timestamp_seconds"]).size()
               .reset_index(name="Detections"))
    return grouped[["timestamp_seconds", "Detections"]]


def format_bytes(n: int) -> str:
    size = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{n} B"


def format_seconds(s: float | None) -> str:
    if s is None:
        return "unknown"
    m, sec = divmod(s, 60)
    return f"{int(m)}m {sec:04.1f}s" if m else f"{sec:.1f}s"


def find_weights(project_root: Path, model_name: str = "yolo11n.pt") -> Path | None:
    """Look for local weights in common locations. Returns None if not found."""
    for candidate in (
        project_root / model_name,
        project_root / "models" / model_name,
        project_root / "weights" / model_name,
        Path.cwd() / model_name,
    ):
        if candidate.is_file():
            return candidate
    return None
