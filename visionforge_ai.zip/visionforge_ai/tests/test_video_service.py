import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _stubs  # noqa: F401,E402

import cv2  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

import video_service as vs  # noqa: E402
from core.video.video_processor import VideoProcessingError, VideoProcessor  # noqa: E402


class FakeBox:
    def __init__(self):
        self.cls = np.array([0], dtype=np.float32)
        self.conf = np.array([0.9], dtype=np.float32)
        self.xyxy = np.array([[10, 10, 50, 50]], dtype=np.float32)

    def __iter__(self):
        yield self


class FakePrediction:
    def __init__(self, frame):
        self.boxes = FakeBox()
        self.frame = frame

    def plot(self):
        return self.frame.copy()


class FakeModel:
    names = {0: "person"}

    def predict(self, source, conf, verbose=False):
        return [FakePrediction(source)]


class FakeEngine:
    def __init__(self):
        self.model = FakeModel()


def make_video(path: Path, frames: int = 6, size=(160, 120)) -> Path:
    w = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), 10, size)
    if not w.isOpened():
        raise unittest.SkipTest("MP4 encoding unavailable")
    for i in range(frames):
        f = np.full((size[1], size[0], 3), i * 10, np.uint8)
        w.write(f)
    w.release()
    return path


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.video = make_video(self.tmp / "clip.mp4")


class ValidationTests(Base):
    def test_extension_size_and_empty(self):
        vs.validate_upload("a.mp4", 10)
        with self.assertRaises(vs.VideoValidationError):
            vs.validate_upload("a.txt", 10)
        with self.assertRaises(vs.VideoValidationError):
            vs.validate_upload("a.mp4", 0)
        with self.assertRaises(vs.VideoValidationError):
            vs.validate_upload("a.mp4", (vs.MAX_VIDEO_MB + 1) * 1024 * 1024)

    def test_save_upload_unique_and_safe_name(self):
        data = self.video.read_bytes()
        a = vs.save_upload(data, "../../evil name.MP4")
        b = vs.save_upload(memoryview(data), "../../evil name.MP4")
        self.addCleanup(vs.remove_tree, a.parent)
        self.addCleanup(vs.remove_tree, b.parent)
        self.assertNotEqual(a.parent, b.parent)
        self.assertEqual(a.name, "input.mp4")
        self.assertEqual(a.read_bytes(), data)

    def test_probe_valid(self):
        meta = vs.probe_video(self.video)
        self.assertEqual((meta.width, meta.height), (160, 120))
        self.assertEqual(meta.frame_count, 6)
        self.assertAlmostEqual(meta.fps, 10.0, places=1)
        self.assertGreater(meta.size_bytes, 0)

    def test_probe_garbage_with_video_extension(self):
        bad = self.tmp / "bad.mp4"
        bad.write_bytes(b"this is not a video" * 50)
        with self.assertRaises(vs.VideoValidationError):
            vs.probe_video(bad)

    def test_estimate_frames_matches_stride_semantics(self):
        meta = vs.probe_video(self.video)  # 6 frames
        self.assertEqual(vs.estimate_frames(meta, 1, None), (6, 6))
        self.assertEqual(vs.estimate_frames(meta, 2, None), (6, 3))   # 0,2,4
        self.assertEqual(vs.estimate_frames(meta, 2, 5), (5, 3))      # 0,2,4
        self.assertEqual(vs.estimate_frames(meta, 4, 4), (4, 1))      # 0


class AnalyzeTests(Base):
    def analyze(self, **kw):
        args = dict(engine=FakeEngine(), input_path=self.video, output_root=self.tmp / "out",
                    confidence=0.25, frame_stride=1, max_frames=None, transcode=False)
        args.update(kw)
        return vs.analyze_video(**args)

    def test_outputs_and_schema(self):
        r = self.analyze()
        self.assertEqual(r["frames_read"], 6)
        self.assertEqual(r["frames_processed"], 6)
        self.assertEqual(r["total_detections"], 6)
        self.assertTrue(Path(r["output_video_path"]).stat().st_size > 0)
        csv = pd.read_csv(r["output_csv_path"])
        self.assertEqual(len(csv), 6)
        self.assertEqual(list(csv.columns), ["frame", "timestamp_seconds", "class_id",
                                             "label", "confidence", "x1", "y1", "x2", "y2"])
        self.assertIsNone(r["playback_path"])
        self.assertIn("Re-encoding was skipped", r["playback_note"])
        self.assertGreater(r["throughput_fps"], 0)

    def test_stride_counts(self):
        r = self.analyze(frame_stride=2, max_frames=5)
        self.assertEqual((r["frames_read"], r["frames_processed"]), (5, 3))

    def test_each_run_gets_its_own_folder(self):
        r1, r2 = self.analyze(), self.analyze()
        self.assertNotEqual(r1["run_dir"], r2["run_dir"])
        self.assertTrue(Path(r1["output_video_path"]).is_file())
        self.assertTrue(Path(r2["output_video_path"]).is_file())

    def test_failure_cleans_run_dir(self):
        out = self.tmp / "out"
        with self.assertRaises(ValueError):
            self.analyze(confidence=2.0)
        with self.assertRaises(FileNotFoundError):
            self.analyze(input_path=self.tmp / "missing.mp4")
        leftovers = [p for p in out.glob("*") if p.is_dir()] if out.exists() else []
        self.assertEqual(leftovers, [])

    def test_unreadable_video_raises_processing_error(self):
        bad = self.tmp / "bad.mp4"
        bad.write_bytes(b"nope" * 100)
        with self.assertRaises(VideoProcessingError):
            self.analyze(input_path=bad)

    def test_progress_callback(self):
        calls = []
        self.analyze(progress_callback=lambda read, total: calls.append((read, total)))
        self.assertEqual([c[0] for c in calls], [1, 2, 3, 4, 5, 6])
        self.assertTrue(all(c[1] == 6 for c in calls))

    def test_progress_total_respects_max_frames(self):
        calls = []
        self.analyze(max_frames=3, progress_callback=lambda r, t: calls.append((r, t)))
        self.assertEqual(calls[-1], (3, 3))

    def test_processor_without_callback_still_works(self):
        r = VideoProcessor(FakeEngine(), output_dir=self.tmp / "plain").process_video(self.video)
        self.assertEqual(r["frames_processed"], 6)


class PlaybackTests(Base):
    def test_no_ffmpeg_returns_none_and_note(self):
        with mock.patch.object(vs, "find_ffmpeg", return_value=None):
            self.assertIsNone(vs.make_web_playable(self.video))
            r = vs.analyze_video(FakeEngine(), self.video, self.tmp / "o", 0.25, 1, None)
        self.assertIsNone(r["playback_path"])
        self.assertIn("FFmpeg was not found", r["playback_note"])

    @unittest.skipUnless(vs.find_ffmpeg(), "FFmpeg not available")
    def test_transcode_produces_h264_file(self):
        out = vs.make_web_playable(self.video)
        self.assertIsNotNone(out)
        self.assertTrue(out.stat().st_size > 0)
        cap = cv2.VideoCapture(str(out))
        try:
            self.assertTrue(cap.isOpened())
            self.assertEqual(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), 6)
            fourcc = int(cap.get(cv2.CAP_PROP_FOURCC)).to_bytes(4, "little").decode("latin1")
            self.assertIn(fourcc.lower(), ("avc1", "h264", "x264"))
        finally:
            cap.release()

    @unittest.skipUnless(vs.find_ffmpeg(), "FFmpeg not available")
    def test_full_analysis_with_transcode(self):
        r = vs.analyze_video(FakeEngine(), self.video, self.tmp / "o", 0.25, 1, None)
        self.assertTrue(Path(r["playback_path"]).is_file())
        self.assertEqual(vs.read_frame(r["playback_path"], 2).shape[:2], (120, 160))

    def test_read_frame_bad_path(self):
        self.assertIsNone(vs.read_frame(self.tmp / "none.mp4", 0))


if __name__ == "__main__":
    unittest.main()
