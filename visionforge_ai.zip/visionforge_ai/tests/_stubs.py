"""Make project imports work in test environments without Ultralytics.

Only used when `ultralytics` is NOT installed; the fakes in the tests never
call YOLO. On a normal install this module does nothing.
"""
import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for p in (ROOT, ROOT / "app"):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

try:
    import ultralytics  # noqa: F401
except ImportError:
    stub = types.ModuleType("ultralytics")
    stub.YOLO = object
    sys.modules["ultralytics"] = stub
