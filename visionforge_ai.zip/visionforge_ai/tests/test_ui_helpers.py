import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _stubs  # noqa: F401,E402
import cv2  # noqa: E402
import helpers  # noqa: E402


class HelperTests(unittest.TestCase):
    def test_decode_invalid_bytes(self):
        self.assertIsNone(helpers.decode_image(b"not an image"))
        self.assertIsNone(helpers.decode_image(b""))

    def test_decode_roundtrip(self):
        img = np.zeros((20, 30, 3), np.uint8)
        data = cv2.imencode(".png", img)[1].tobytes()
        out = helpers.decode_image(data)
        self.assertEqual(out.shape, (20, 30, 3))

    def test_hash_differs(self):
        self.assertNotEqual(helpers.file_hash(b"a"), helpers.file_hash(b"b"))

    def test_temp_file_removed_on_success_and_error(self):
        img = np.zeros((8, 8, 3), np.uint8)
        with helpers.temporary_image_file(img) as p:
            self.assertTrue(p.exists())
        self.assertFalse(p.exists())
        with self.assertRaises(ValueError):
            with helpers.temporary_image_file(img) as p2:
                raise ValueError
        self.assertFalse(p2.exists())

    def test_temp_files_are_unique(self):
        img = np.zeros((8, 8, 3), np.uint8)
        with helpers.temporary_image_file(img) as a, helpers.temporary_image_file(img) as b:
            self.assertNotEqual(a, b)

    def test_detections_frame_and_empty(self):
        self.assertTrue(helpers.detections_to_frame([]).empty)
        self.assertTrue(helpers.detections_to_frame(None).empty)
        f = helpers.detections_to_frame(
            [{"label": "person", "confidence": 0.9}, {"label": "dog", "confidence": 0.5}])
        self.assertEqual(list(f.columns), ["ID", "Object", "Confidence"])
        self.assertEqual(len(f), 2)
        self.assertIn("person,0.9", f.to_csv(index=False))

    def test_distribution(self):
        f = helpers.detections_to_frame([{"label": "a", "confidence": .1}] * 2
                                        + [{"label": "b", "confidence": .2}])
        d = helpers.class_distribution(f)
        self.assertEqual(d.iloc[0].tolist(), ["a", 2])
        self.assertTrue(helpers.class_distribution(helpers.detections_to_frame([])).empty)

    def test_summary_and_history(self):
        result = {"detections": [{"label": "cat", "confidence": 0.8}], "object_count": 1,
                  "inference_time_ms": 12.5, "image_width": 10, "image_height": 5}
        rec = helpers.summarize_analysis("x.png", result, 0.25)
        self.assertEqual(rec["objects"], 1)
        self.assertAlmostEqual(rec["mean_confidence"], 0.8)
        empty = helpers.summarize_analysis("y.png", {"detections": [], "object_count": 0}, 0.5)
        self.assertIsNone(empty["mean_confidence"])
        h = helpers.history_frame([rec, empty])
        self.assertEqual(len(h), 1)

    def test_image_detections_include_bbox_from_real_schema(self):
        d = [{"class_id": 0, "label": "person", "confidence": 0.9,
              "bbox": {"x1": 1, "y1": 2, "x2": 3, "y2": 4}}]
        f = helpers.detections_to_frame(d)
        self.assertEqual(list(f.columns), ["ID", "Object", "Confidence", "x1", "y1", "x2", "y2"])
        self.assertEqual(f.iloc[0][["x1", "y1", "x2", "y2"]].tolist(), [1, 2, 3, 4])

    def test_summarize_video_and_history_kinds(self):
        result = {"total_detections": 2, "frames_read": 5, "frames_processed": 3,
                  "processing_time_seconds": 1.5, "video_width": 10, "video_height": 5,
                  "detections": [
                      {"frame": 0, "timestamp_seconds": 0.0, "class_id": 0, "label": "person",
                       "confidence": 0.8, "x1": 0, "y1": 0, "x2": 1, "y2": 1},
                      {"frame": 2, "timestamp_seconds": 0.2, "class_id": 0, "label": "person",
                       "confidence": 0.6, "x1": 0, "y1": 0, "x2": 1, "y2": 1}]}
        v = helpers.summarize_video("v.mp4", result, 0.25, 2, None)
        self.assertEqual((v["kind"], v["objects"], v["frames_processed"]), ("video", 2, 3))
        self.assertAlmostEqual(v["mean_confidence"], 0.7)
        img = helpers.summarize_analysis("i.png", {"detections": [], "object_count": 0}, 0.5)
        self.assertEqual(img["kind"], "image")
        h = helpers.history_frame([img, v])
        self.assertEqual(h["Kind"].tolist(), ["video", "video"])
        per = helpers.detections_per_frame(helpers.video_records_frame(result))
        self.assertEqual(per["Detections"].tolist(), [1, 1])
        self.assertTrue(helpers.video_records_frame({"detections": []}).empty)

    def test_formatters(self):
        self.assertEqual(helpers.format_bytes(512), "512 B")
        self.assertEqual(helpers.format_bytes(2048), "2.0 KB")
        self.assertEqual(helpers.format_seconds(None), "unknown")
        self.assertEqual(helpers.format_seconds(5.25), "5.2s")
        self.assertTrue(helpers.format_seconds(125).startswith("2m"))

    def test_find_weights_missing(self):
        self.assertIsNone(helpers.find_weights(Path("/nonexistent"), "nope.pt"))


if __name__ == "__main__":
    unittest.main()
