"""License plate detection + OCR service (no Streamlit imports; fully testable).

Design rules
------------
* Plate detection needs a plate-trained YOLO model. A general COCO model (e.g.
  yolo11n.pt) is REJECTED: its class names contain no plate class, and this
  module refuses to report "plates" from it.
* Detection confidence and OCR confidence are separate numbers and are never mixed.
* OCR is optional. If EasyOCR (or its model files) is missing, detection still
  works and each plate is marked ``ocr_status="unavailable"``.
* Nothing here sends data over a network. EasyOCR itself downloads its model
  files on first use; see ``ocr_dependency_status``.
"""
from __future__ import annotations

import importlib.util
import json
import logging
import math
import os
import re
from dataclasses import dataclass
from datetime import datetime
from importlib import metadata
from pathlib import Path
from time import perf_counter
from typing import Any, Callable, Protocol

import cv2
import numpy as np
import pandas as pd

log = logging.getLogger("visionforge.plates")

PLATE_MODEL_ENV = "VISIONFORGE_PLATE_MODEL"
DEFAULT_PLATE_MODEL = Path("models") / "license_plate_detector.pt"
PLATE_NAME_PATTERN = re.compile(
    r"(licen[sc]e|number[\s_-]?plate|\bplates?\b|registration|\blp\b|\bnp\b)", re.I
)
OCR_ALLOWLIST = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
LOW_DET_CONF = 0.50
LOW_OCR_CONF = 0.50
MAX_IMAGE_MB = 20


class PlateModelError(RuntimeError):
    """The plate model is missing, unloadable, or not a plate detector."""


class OCRUnavailableError(RuntimeError):
    """OCR cannot run (package missing, or model files could not be loaded)."""


# ------------------------------------------------------------------ configuration
def default_plate_model_path(project_root: Path) -> Path:
    """Configured path: env var VISIONFORGE_PLATE_MODEL, else models/license_plate_detector.pt."""
    env = os.environ.get(PLATE_MODEL_ENV, "").strip().strip('"')
    return Path(env).expanduser() if env else Path(project_root) / DEFAULT_PLATE_MODEL


def plate_model_file_status(path: str | Path | None) -> dict[str, Any]:
    """Cheap file-level check (does NOT load the model)."""
    if not path:
        return {"state": "missing", "path": None, "detail": "No path configured."}
    p = Path(path)
    if not p.is_file():
        return {"state": "missing", "path": str(p), "detail": "File not found."}
    if p.suffix.lower() != ".pt":
        return {"state": "invalid", "path": str(p), "detail": "Expected a .pt weights file."}
    size = p.stat().st_size
    if size == 0:
        return {"state": "invalid", "path": str(p), "detail": "File is empty."}
    return {"state": "found", "path": str(p), "size_mb": round(size / 1024 / 1024, 1),
            "detail": "Weights file present (not yet loaded)."}


def ocr_dependency_status() -> dict[str, Any]:
    """Report EasyOCR readiness without importing torch or downloading anything."""
    installed = importlib.util.find_spec("easyocr") is not None
    info: dict[str, Any] = {"installed": installed, "version": None, "weights_cached": None}
    if installed:
        try:
            info["version"] = metadata.version("easyocr")
        except metadata.PackageNotFoundError:
            pass
        model_dir = Path(os.environ.get("EASYOCR_MODULE_PATH", Path.home() / ".EasyOCR")) / "model"
        needed = ("craft_mlt_25k.pth", "english_g2.pth")
        info["model_dir"] = str(model_dir)
        info["weights_cached"] = all((model_dir / n).is_file() for n in needed)
    return info


# ------------------------------------------------------------------ geometry
def clamp_box(x1: float, y1: float, x2: float, y2: float, width: int, height: int,
              pad: float = 0.0) -> tuple[int, int, int, int] | None:
    """Order, pad (fraction of box size) and clamp a box to the image.

    Returns integer (x1, y1, x2, y2) or None if less than 2 px remain on a side.
    """
    x1, x2 = sorted((float(x1), float(x2)))
    y1, y2 = sorted((float(y1), float(y2)))
    px, py = (x2 - x1) * pad, (y2 - y1) * pad
    nx1, ny1 = max(0, math.floor(x1 - px)), max(0, math.floor(y1 - py))
    nx2, ny2 = min(width, math.ceil(x2 + px)), min(height, math.ceil(y2 + py))
    if nx2 - nx1 < 2 or ny2 - ny1 < 2:
        return None
    return int(nx1), int(ny1), int(nx2), int(ny2)


def resolve_plate_class_ids(names: dict[int, str]) -> tuple[list[int], list[str]]:
    """Pick the class ids that mean 'license plate'. Raises for general models."""
    if not names:
        raise PlateModelError("The model reports no class names, so it cannot be verified as a plate detector.")
    matches = [int(i) for i, n in names.items() if PLATE_NAME_PATTERN.search(str(n))]
    if matches:
        return matches, []
    if len(names) == 1:
        only_id, only_name = next(iter(names.items()))
        return [int(only_id)], [
            f"The model has a single class named '{only_name}'; it is being treated as the plate class."]
    preview = ", ".join(str(n) for n in list(names.values())[:8])
    more = "…" if len(names) > 8 else ""
    raise PlateModelError(
        f"None of this model's {len(names)} classes look like license plates ({preview}{more}). "
        "This looks like a general-purpose model (for example COCO), not a plate detector. "
        "Use weights trained to detect license plates.")


# ------------------------------------------------------------------ OCR
@dataclass
class OCRReading:
    text: str
    confidence: float | None  # the recognizer's own score, 0..1; NOT the detection confidence
    variant: str = ""


class OCRBackend(Protocol):
    name: str

    def read(self, image_bgr: np.ndarray) -> list[tuple[Any, str, float]]:
        """Return (box_points, text, confidence) segments."""


class EasyOCRBackend:
    """Thin lazy wrapper around easyocr.Reader (CPU by default)."""

    name = "EasyOCR"

    def __init__(self, languages: tuple[str, ...] = ("en",), gpu: bool = False) -> None:
        self.languages = languages
        self.gpu = gpu
        self._reader: Any = None

    def _get_reader(self):
        if self._reader is None:
            try:
                import easyocr
            except ImportError as exc:
                raise OCRUnavailableError(
                    "EasyOCR is not installed. Install it with: pip install easyocr") from exc
            try:
                self._reader = easyocr.Reader(list(self.languages), gpu=self.gpu, verbose=False)
            except Exception as exc:  # download/network/permission/torch problems
                log.exception("EasyOCR reader could not be created")
                raise OCRUnavailableError(
                    "EasyOCR could not load its model files. The first run downloads them "
                    f"(needs internet, roughly 100 MB). Details: {exc}") from exc
        return self._reader

    def read(self, image_bgr: np.ndarray) -> list[tuple[Any, str, float]]:
        reader = self._get_reader()
        return reader.readtext(image_bgr, allowlist=OCR_ALLOWLIST, detail=1, paragraph=False)


def preprocess_variants(crop_bgr: np.ndarray) -> list[tuple[str, np.ndarray]]:
    """Upscaled colour crop, and a contrast-enhanced (CLAHE) grayscale version."""
    h, w = crop_bgr.shape[:2]
    scale = max(1.0, 80.0 / max(h, 1))
    scale = min(scale, 1200.0 / max(w, 1)) if w * scale > 1200 else scale
    up = cv2.resize(crop_bgr, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC) if scale != 1.0 else crop_bgr
    gray = cv2.cvtColor(up, cv2.COLOR_BGR2GRAY)
    enhanced = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray)
    return [("upscaled", up), ("clahe", cv2.cvtColor(enhanced, cv2.COLOR_GRAY2BGR))]


def assemble_text(segments: list[tuple[Any, str, float]]) -> OCRReading:
    """Join OCR segments in reading order (lines top→bottom, left→right)."""
    items = []
    for box, text, conf in segments:
        text = re.sub(r"[^A-Za-z0-9]", "", str(text)).upper()
        if not text:
            continue
        pts = np.array(box, dtype=float).reshape(-1, 2)
        items.append({"text": text, "conf": float(conf), "cx": pts[:, 0].mean(),
                      "cy": pts[:, 1].mean(), "h": max(np.ptp(pts[:, 1]), 1.0)})
    if not items:
        return OCRReading("", None)
    items.sort(key=lambda d: d["cy"])
    tol = 0.6 * float(np.median([d["h"] for d in items]))
    lines: list[list[dict]] = [[items[0]]]
    for it in items[1:]:
        if abs(it["cy"] - np.mean([d["cy"] for d in lines[-1]])) <= tol:
            lines[-1].append(it)
        else:
            lines.append([it])
    ordered = [d for line in lines for d in sorted(line, key=lambda d: d["cx"])]
    text = " ".join(d["text"] for d in ordered)
    return OCRReading(text, float(np.mean([d["conf"] for d in ordered])))


def read_plate_text(ocr: OCRBackend, crop_bgr: np.ndarray) -> OCRReading:
    """OCR a plate crop; try a second preprocessing variant only if the first is weak."""
    best = OCRReading("", None)
    for name, img in preprocess_variants(crop_bgr):
        reading = assemble_text(ocr.read(img))
        reading.variant = name
        if reading.text and (best.confidence is None or (reading.confidence or 0) > best.confidence):
            best = reading
        if best.text and (best.confidence or 0) >= 0.6:
            break
    return best


# ------------------------------------------------------------------ service
class LicensePlateService:
    """Detect plates with a plate-trained YOLO model and read them with OCR."""

    def __init__(self, model: Any, ocr: OCRBackend | None = None, model_path: str = "") -> None:
        self.model = model
        self.ocr = ocr
        self.model_path = model_path
        names = getattr(model, "names", None)
        self.class_names: dict[int, str] = dict(names) if names else {}
        self.class_ids, self.model_warnings = resolve_plate_class_ids(self.class_names)

    @classmethod
    def from_weights(cls, path: str | Path, ocr: OCRBackend | None = None,
                     loader: Callable[[str], Any] | None = None) -> "LicensePlateService":
        status = plate_model_file_status(path)
        if status["state"] != "found":
            raise PlateModelError(f"Plate model unavailable: {status['detail']} ({status['path']})")
        if loader is None:
            try:
                from ultralytics import YOLO as loader  # type: ignore[assignment]
            except ImportError as exc:
                raise PlateModelError("Ultralytics is not installed.") from exc
        try:
            model = loader(str(path))
        except Exception as exc:
            log.exception("Plate model failed to load: %s", path)
            raise PlateModelError(
                f"Could not load '{Path(path).name}': {exc}. The file may be corrupt or incompatible "
                "with the installed Ultralytics version.") from exc
        return cls(model, ocr=ocr, model_path=str(path))

    def analyze_image(self, image_bgr: np.ndarray, confidence: float = 0.25,
                      run_ocr: bool = True) -> dict[str, Any]:
        if not isinstance(image_bgr, np.ndarray) or image_bgr.ndim != 3 or image_bgr.shape[2] != 3:
            raise ValueError("Expected a 3-channel BGR image array.")
        if not 0.0 <= confidence <= 1.0:
            raise ValueError("Confidence must be between 0.0 and 1.0.")
        height, width = image_bgr.shape[:2]

        t0 = perf_counter()
        predictions = self.model.predict(source=image_bgr, conf=confidence, verbose=False)
        detection_ms = (perf_counter() - t0) * 1000
        if not predictions:
            raise RuntimeError("The plate model returned no prediction result.")
        boxes = predictions[0].boxes

        raw = []
        if boxes is not None:
            for box in boxes:
                class_id = int(box.cls.item())
                if class_id not in self.class_ids:
                    continue
                raw.append((float(box.conf.item()), class_id, [float(v) for v in box.xyxy[0].tolist()]))
        raw.sort(key=lambda r: -r[0])

        detections: list[dict[str, Any]] = []
        skipped = 0
        for conf, class_id, xyxy in raw:
            clamped = clamp_box(*xyxy, width, height)
            padded = clamp_box(*xyxy, width, height, pad=0.06)
            if clamped is None or padded is None:
                skipped += 1
                continue
            x1, y1, x2, y2 = clamped
            px1, py1, px2, py2 = padded
            warnings = []
            if conf < LOW_DET_CONF:
                warnings.append("Low detection confidence")
            if y2 - y1 < 24:
                warnings.append("Plate region is very small; OCR is unreliable")
            if x1 <= 0 or y1 <= 0 or x2 >= width or y2 >= height:
                warnings.append("Plate touches the image edge and may be cut off")
            detections.append({
                "plate_id": len(detections) + 1, "class_id": class_id,
                "class_name": self.class_names.get(class_id, str(class_id)),
                "detection_confidence": round(conf, 4),
                "bbox": {"x1": x1, "y1": y1, "x2": x2, "y2": y2},
                "crop": image_bgr[py1:py2, px1:px2].copy(),
                "plate_text": "", "ocr_confidence": None, "ocr_status": "disabled",
                "ocr_error": None, "ocr_variant": "", "warnings": warnings,
            })

        ocr_error: str | None = None
        ocr_ms = 0.0
        if run_ocr:
            t1 = perf_counter()
            if self.ocr is None:
                ocr_error = "No OCR backend is configured."
                for d in detections:
                    d["ocr_status"] = "unavailable"
            else:
                for d in detections:
                    if ocr_error:  # OCR already known to be unavailable
                        d["ocr_status"] = "unavailable"
                        continue
                    try:
                        reading = read_plate_text(self.ocr, d["crop"])
                    except OCRUnavailableError as exc:
                        ocr_error = str(exc)
                        d["ocr_status"] = "unavailable"
                        continue
                    except Exception as exc:  # one bad plate must not lose the others
                        log.exception("OCR failed for plate %s", d["plate_id"])
                        d["ocr_status"], d["ocr_error"] = "error", f"{type(exc).__name__}: {exc}"
                        d["warnings"].append("OCR failed for this plate")
                        continue
                    d["ocr_variant"] = reading.variant
                    if reading.text:
                        d["plate_text"], d["ocr_confidence"], d["ocr_status"] = reading.text, reading.confidence, "ok"
                        if reading.confidence is not None and reading.confidence < LOW_OCR_CONF:
                            d["warnings"].append("Low OCR confidence; verify the text")
                    else:
                        d["ocr_status"] = "no_text"
                        d["warnings"].append("No text recognised")
            ocr_ms = (perf_counter() - t1) * 1000

        return {
            "image_width": width, "image_height": height,
            "detections": detections, "plate_count": len(detections), "skipped_degenerate": skipped,
            "annotated_image": self._annotate(image_bgr, detections),
            "detection_time_ms": round(detection_ms, 2), "ocr_time_ms": round(ocr_ms, 2),
            "inference_time_ms": round(detection_ms + ocr_ms, 2),
            "ocr_requested": bool(run_ocr), "ocr_backend": getattr(self.ocr, "name", None),
            "ocr_error": ocr_error, "model_path": self.model_path,
            "model_warnings": list(self.model_warnings),
        }

    @staticmethod
    def _annotate(image: np.ndarray, detections: list[dict[str, Any]]) -> np.ndarray:
        out = image.copy()
        h, w = out.shape[:2]
        thick = max(2, round(min(h, w) / 300))
        scale = max(0.5, min(h, w) / 900)
        for d in detections:
            b = d["bbox"]
            cv2.rectangle(out, (b["x1"], b["y1"]), (b["x2"], b["y2"]), (238, 216, 63), thick)
            label = f"#{d['plate_id']} det {d['detection_confidence']:.2f}"
            if d["plate_text"]:
                label += f" | {d['plate_text']}"
            (tw, th), base = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, scale, 1)
            top = b["y1"] - th - base - 4
            if top < 0:
                top = b["y2"]
            cv2.rectangle(out, (b["x1"], top), (min(w, b["x1"] + tw + 6), top + th + base + 4), (40, 30, 10), -1)
            cv2.putText(out, label, (b["x1"] + 3, top + th + 1), cv2.FONT_HERSHEY_SIMPLEX,
                        scale, (255, 255, 255), 1, cv2.LINE_AA)
        return out


# ------------------------------------------------------------------ exports + history
ROW_COLUMNS = ["image", "plate_id", "x1", "y1", "x2", "y2", "detection_confidence",
               "ocr_text", "ocr_confidence", "ocr_status", "manual_correction", "warnings"]


def plate_rows(result: dict[str, Any], filename: str,
               corrections: dict[int, str] | None = None) -> list[dict[str, Any]]:
    """Export rows. ``ocr_text`` is always the original OCR output; corrections are separate."""
    corrections = corrections or {}
    rows = []
    for d in result["detections"]:
        fixed = (corrections.get(d["plate_id"]) or "").strip()
        rows.append({
            "image": filename, "plate_id": d["plate_id"], **d["bbox"],
            "detection_confidence": d["detection_confidence"],
            "ocr_text": d["plate_text"], "ocr_confidence": d["ocr_confidence"],
            "ocr_status": d["ocr_status"],
            "manual_correction": fixed if fixed and fixed != d["plate_text"] else "",
            "warnings": "; ".join(d["warnings"]),
        })
    return rows


def rows_to_csv(rows: list[dict[str, Any]]) -> str:
    return pd.DataFrame(rows, columns=ROW_COLUMNS).to_csv(index=False)


def build_json_report(result: dict[str, Any], filename: str, threshold: float,
                      corrections: dict[int, str] | None = None) -> str:
    report = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "image": {"name": filename, "width": result["image_width"], "height": result["image_height"]},
        "settings": {"detection_confidence_threshold": threshold, "ocr_requested": result["ocr_requested"]},
        "model": {"path_name": Path(result["model_path"]).name if result["model_path"] else None,
                  "warnings": result["model_warnings"]},
        "ocr": {"backend": result["ocr_backend"], "error": result["ocr_error"]},
        "timing_ms": {"detection": result["detection_time_ms"], "ocr": result["ocr_time_ms"],
                      "total": result["inference_time_ms"]},
        "note": "ocr_confidence is the OCR engine's own score and is not the detection confidence.",
        "plates": plate_rows(result, filename, corrections),
    }
    return json.dumps(report, indent=2)


def summarize_plate(filename: str, result: dict[str, Any], threshold: float) -> dict[str, Any]:
    """Session-history record (no image data) for the Command Center and Analytics."""
    dets = result["detections"]
    confs = [d["detection_confidence"] for d in dets]
    attempted = result["ocr_requested"]
    return {
        "kind": "plate", "filename": filename, "threshold": float(threshold),
        "objects": len(dets), "inference_ms": float(result["inference_time_ms"]),
        "processing_seconds": float(result["inference_time_ms"]) / 1000.0,
        "width": result["image_width"], "height": result["image_height"],
        "mean_confidence": float(np.mean(confs)) if confs else None,
        "classes": ["license_plate"] * len(dets), "confidences": confs,
        "ocr_attempted": bool(attempted and dets),
        "ocr_read": sum(d["ocr_status"] == "ok" for d in dets),
        "ocr_failed": sum(d["ocr_status"] in ("no_text", "error", "unavailable") for d in dets) if attempted else 0,
    }
