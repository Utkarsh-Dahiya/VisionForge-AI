"""Pure, Streamlit-free helpers so they can be unit-tested without a server."""
from __future__ import annotations

import hashlib
import os
import tempfile
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Iterator

import cv2
import numpy as np
import pandas as pd

ALLOWED_TYPES = ["jpg", "jpeg", "png", "webp"]


def file_hash(data: bytes | memoryview) -> str:
    return hashlib.sha256(data).hexdigest()


def decode_image(data: bytes) -> np.ndarray | None:
    """Decode bytes into a BGR image, or None if the bytes are not an image."""
    if not data:
        return None
    return cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)


def to_rgb(image_bgr: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)


def encode_png(image_bgr: np.ndarray) -> bytes | None:
    ok, buf = cv2.imencode(".png", image_bgr)
    return buf.tobytes() if ok else None


@contextmanager
def temporary_image_file(image_bgr: np.ndarray) -> Iterator[Path]:
    """Write an image to a unique temp file and always delete it afterwards.

    A unique name per call avoids collisions between concurrent sessions.
    """
    fd, name = tempfile.mkstemp(prefix="visionforge_", suffix=".png")
    os.close(fd)
    path = Path(name)
    try:
        if not cv2.imwrite(str(path), image_bgr):
            raise RuntimeError("Could not prepare the input image.")
        yield path
    finally:
        path.unlink(missing_ok=True)


def detections_to_frame(detections: list[dict[str, Any]] | None) -> pd.DataFrame:
    """Build the display table from the engine's `detections` list.

    Uses `label`, `confidence` and, when present, the nested `bbox` dict.
    """
    columns = ["ID", "Object", "Confidence"]
    has_box = bool(detections) and any("bbox" in d for d in detections)
    if has_box:
        columns += ["x1", "y1", "x2", "y2"]
    if not detections:
        return pd.DataFrame(columns=columns)
    rows = []
    for i, d in enumerate(detections, start=1):
        row = {"ID": i, "Object": d.get("label", "unknown"),
               "Confidence": float(d.get("confidence", 0.0))}
        if has_box:
            box = d.get("bbox") or {}
            row.update({k: box.get(k) for k in ("x1", "y1", "x2", "y2")})
        rows.append(row)
    return pd.DataFrame(rows, columns=columns)


def class_distribution(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return pd.DataFrame(columns=["Object", "Count"])
    return (
        frame["Object"].value_counts().rename_axis("Object").reset_index(name="Count")
    )


def summarize_analysis(
    filename: str, result: dict[str, Any], threshold: float
) -> dict[str, Any]:
    """Compact record stored in session history (no image data)."""
    frame = detections_to_frame(result.get("detections"))
    return {
        "kind": "image",
        "filename": filename,
        "threshold": threshold,
        "objects": int(result.get("object_count", len(frame))),
        "inference_ms": float(result.get("inference_time_ms", 0.0)),
        "width": int(result.get("image_width", 0)),
        "height": int(result.get("image_height", 0)),
        "mean_confidence": float(frame["Confidence"].mean()) if len(frame) else None,
        "classes": frame["Object"].tolist(),
        "confidences": frame["Confidence"].tolist(),
        "processing_seconds": float(result.get("inference_time_ms", 0.0)) / 1000.0,
    }


def history_frame(history: list[dict[str, Any]]) -> pd.DataFrame:
    """Flatten every detection across the session into one frame."""
    rows = []
    for n, record in enumerate(history, start=1):
        for lbl, conf in zip(record["classes"], record["confidences"]):
            rows.append(
                {"Analysis": n, "Kind": record.get("kind", "image"),
                 "Image": record["filename"], "Object": lbl, "Confidence": conf}
            )
    return pd.DataFrame(rows, columns=["Analysis", "Kind", "Image", "Object", "Confidence"])


def stamp(record: dict[str, Any]) -> dict[str, Any]:
    """Add the real completion time to a history record (no invented values)."""
    record["completed_at"] = datetime.now().isoformat(timespec="seconds")
    return record


def processing_label(record: dict[str, Any]) -> str:
    """Human-readable processing time for any history record."""
    if record.get("kind") == "video":
        secs = record.get("processing_seconds", record.get("processing_time_seconds"))
        return format_seconds(secs)
    return f"{record.get('inference_ms', 0.0):.0f} ms"


def find_weights(project_root: Path, model_name: str = "yolo11n.pt") -> Path | None:
    """Look for local weights in common locations. Returns None if not found."""
    for candidate in (
        project_root / model_name,
        project_root / "models" / model_name,
        project_root / "weights" / model_name,
        Path.cwd() / model_name,
    ):
        if candidate.is_file():
            return candidate
    return None
def format_bytes(size_bytes: int) -> str:
    """Convert a file size in bytes into a human-readable format."""
    size = float(size_bytes)

    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            if unit == "B":
                return f"{int(size)} {unit}"
            return f"{size:.2f} {unit}"
        size /= 1024

    return f"{size_bytes} B"
def format_seconds(seconds: float) -> str:
    """Convert seconds into a human-readable duration."""
    if seconds is None:
        return "N/A"

    total_seconds = max(0, int(seconds))
    hours, remainder = divmod(total_seconds, 3600)
    minutes, secs = divmod(remainder, 60)

    if hours:
        return f"{hours}:{minutes:02d}:{secs:02d}"

    return f"{minutes}:{secs:02d}"


def video_records_frame(result: dict[str, Any] | None) -> pd.DataFrame:
    """Return video detections as a stable, display-ready DataFrame."""
    columns = [
        "frame", "timestamp_seconds", "class_id", "label", "confidence",
        "x1", "y1", "x2", "y2",
    ]
    records = (result or {}).get("detections") or []
    frame = pd.DataFrame.from_records(records)
    for column in columns:
        if column not in frame.columns:
            frame[column] = pd.Series(dtype="object")
    frame = frame[columns]
    if not frame.empty:
        frame["frame"] = pd.to_numeric(frame["frame"], errors="coerce").fillna(0).astype(int)
        frame["timestamp_seconds"] = pd.to_numeric(
            frame["timestamp_seconds"], errors="coerce"
        ).fillna(0.0)
        frame["class_id"] = pd.to_numeric(frame["class_id"], errors="coerce")
        frame["confidence"] = pd.to_numeric(
            frame["confidence"], errors="coerce"
        ).fillna(0.0)
        for column in ("x1", "y1", "x2", "y2"):
            frame[column] = pd.to_numeric(frame[column], errors="coerce")
        frame["label"] = frame["label"].fillna("unknown").astype(str)
        frame = frame.sort_values(["frame", "timestamp_seconds"], kind="stable").reset_index(drop=True)
    return frame


def detections_per_frame(frame: pd.DataFrame) -> pd.DataFrame:
    """Count detected boxes for each processed source frame."""
    columns = ["frame", "timestamp_seconds", "Detections"]
    if frame is None or frame.empty:
        return pd.DataFrame(columns=columns)
    required = {"frame", "timestamp_seconds"}
    if not required.issubset(frame.columns):
        return pd.DataFrame(columns=columns)
    return (
        frame.groupby(["frame", "timestamp_seconds"], dropna=False)
        .size()
        .reset_index(name="Detections")
        .sort_values("frame", kind="stable")
        .reset_index(drop=True)[columns]
    )


def summarize_video(
    filename: str,
    result: dict[str, Any],
    threshold: float,
    stride: int,
    max_frames: int | None,
) -> dict[str, Any]:
    """Compact video-analysis record compatible with the session history view."""
    frame = video_records_frame(result)
    processing_seconds = float(result.get("processing_time_seconds", 0.0) or 0.0)
    return {
        "kind": "video",
        "filename": filename,
        "threshold": float(threshold),
        "stride": int(stride),
        "max_frames": max_frames,
        "objects": int(result.get("total_detections", len(frame))),
        "inference_ms": processing_seconds * 1000.0,
        "width": int(result.get("video_width", 0) or 0),
        "height": int(result.get("video_height", 0) or 0),
        "mean_confidence": float(frame["confidence"].mean()) if not frame.empty else None,
        "classes": frame["label"].tolist(),
        "confidences": frame["confidence"].astype(float).tolist(),
        "frames_read": int(result.get("frames_read", 0) or 0),
        "frames_processed": int(result.get("frames_processed", 0) or 0),
        "processing_time_seconds": processing_seconds,
        "processing_seconds": processing_seconds,
    }
