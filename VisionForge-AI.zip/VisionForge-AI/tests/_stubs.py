"""Make project imports work in test environments without Ultralytics.

Only active when `ultralytics` is NOT installed; the fakes used in tests never
call YOLO. On a normal install this module does nothing but fix sys.path.
"""
import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

try:
    import ultralytics  # noqa: F401
except ImportError:
    stub = types.ModuleType("ultralytics")
    stub.YOLO = object
    sys.modules["ultralytics"] = stub
