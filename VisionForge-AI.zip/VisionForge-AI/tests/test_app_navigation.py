"""Logic-level tests of mainn2.py: navigation, page renderers, error states and flows.

These run the real script against a recording Streamlit stand-in with fake models.
They do not prove the layout looks right in a browser.
"""
import ast
import os
import runpy
import shutil
import sys
import tempfile
import types
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _stubs  # noqa: F401,E402
import streamlit_stub as stub  # noqa: E402

import cv2  # noqa: E402
import numpy as np  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "mainn2.py"
PAGES = ["Command Center", "Vision Studio", "License Plate Studio",
         "Video Intelligence", "Analytics", "Platform Overview"]


class StaticTests(unittest.TestCase):
    def setUp(self):
        self.tree = ast.parse(MAIN.read_text(encoding="utf-8"))

    def test_modules_exports_everything_mainn2_imports(self):
        """Regression for: ImportError: cannot import name 'APP_PHASE' from 'modules'."""
        import modules
        for node in ast.walk(self.tree):
            if isinstance(node, ast.ImportFrom) and node.module == "modules":
                for alias in node.names:
                    self.assertTrue(hasattr(modules, alias.name), alias.name)

    def test_pages_registered_with_renderers(self):
        import modules
        self.assertEqual(modules.PAGES, PAGES)
        keys = None
        funcs = {n.name for n in self.tree.body if isinstance(n, ast.FunctionDef)}
        for node in self.tree.body:
            if isinstance(node, ast.Assign) and getattr(node.targets[0], "id", "") == "PAGE_RENDERERS":
                keys = {k.value: v.id for k, v in zip(node.value.keys, node.value.values)}
        self.assertEqual(sorted(keys), sorted(PAGES))
        for page, fn in keys.items():
            self.assertIn(fn, funcs, f"renderer for {page} is not defined")

    def test_every_module_navigation_target_is_a_page(self):
        import modules
        for m in modules.MODULES:
            self.assertTrue(m["target"] is None or m["target"] in modules.PAGES)

    def test_single_navigation_widget(self):
        radios = [n for n in ast.walk(self.tree) if isinstance(n, ast.Call)
                  and getattr(n.func, "attr", "") == "radio"]
        self.assertEqual(len(radios), 1)

    def _components(self):
        h = stub.Harness()
        undo = stub.install(h)
        self.addCleanup(undo)
        import components
        return components

    def test_shipped_stylesheet_does_not_hide_the_sidebar(self):
        components = self._components()
        css = (ROOT / "assets" / "neural.css").read_text(encoding="utf-8")
        self.assertFalse(components.css_hides_sidebar(css))

    def test_old_stylesheet_is_detected_and_guard_overrides_it(self):
        components = self._components()
        old = ('[data-testid="stSidebar"],[data-testid="stSidebarCollapsedControl"]{display:none}\n'
               'div[data-testid="stRadio"]>label{display:none}')
        self.assertTrue(components.css_hides_sidebar(old))
        # rules that merely sit inside the sidebar are fine
        inner = '[data-testid="stSidebar"] div[data-testid="stRadio"]>label{display:none}'
        self.assertFalse(components.css_hides_sidebar(inner))
        self.assertIn('[data-testid="stSidebar"]{display:flex !important', components.NAV_GUARD_CSS)

    def test_old_css_from_the_original_zip_is_caught_end_to_end(self):
        """inject_theme() flags a stale stylesheet and still appends the guard."""
        components = self._components()
        old_css = '.stApp{color:#fff}\n[data-testid="stSidebar"],[data-testid="stSidebarCollapsedControl"]{display:none}\n'
        tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, tmp, True)
        f = tmp / "neural.css"
        f.write_text(old_css, encoding="utf-8")
        components._CSS_CANDIDATES = (f,)
        info = components.inject_theme()
        self.assertTrue(info["stale_sidebar_rule"])


class AppCase(unittest.TestCase):
    """Runs mainn2.py against stubs with a fake general detector."""

    def setUp(self):
        self.h = stub.Harness()
        self.undo = stub.install(self.h)
        self.saved_engine = sys.modules.get("core.detection.detection_engine")
        self.saved_processor = sys.modules.get("core.video.video_processor")
        self.saved_env = os.environ.get("VISIONFORGE_PLATE_MODEL")
        self.outputs_existed = (ROOT / "outputs").exists()
        self.tmp = Path(tempfile.mkdtemp())
        sys.modules["core.detection.detection_engine"] = self._fake_engine_module()
        for name in ("video_service", "license_plate_service"):
            sys.modules.pop(name, None)
        self.addCleanup(self._cleanup)

    def _cleanup(self):
        self.undo()
        if self.saved_engine is None:
            sys.modules.pop("core.detection.detection_engine", None)
        else:
            sys.modules["core.detection.detection_engine"] = self.saved_engine
        if self.saved_processor is None:
            sys.modules.pop("core.video.video_processor", None)
        else:  # keep the original module object so other tests see the same exception classes
            sys.modules["core.video.video_processor"] = self.saved_processor
        if self.saved_env is None:
            os.environ.pop("VISIONFORGE_PLATE_MODEL", None)
        else:
            os.environ["VISIONFORGE_PLATE_MODEL"] = self.saved_env
        shutil.rmtree(self.tmp, True)
        if not self.outputs_existed:
            shutil.rmtree(ROOT / "outputs", True)

    @staticmethod
    def _fake_engine_module():
        class Box:
            cls = np.array([0.]); conf = np.array([.9]); xyxy = np.array([[5, 5, 40, 40.]])
            def __iter__(self): yield self
        class Pred:
            def __init__(self, f): self.f, self.boxes = f, Box()
            def plot(self): return self.f.copy()
        class Model:
            names = {0: "person"}; device = "cpu"
            def predict(self, source, conf, verbose=False): return [Pred(source)]
        class Engine:
            def __init__(self, model_path=""): self.model = Model()
            def detect_image(self, image_path, confidence=.25):
                im = cv2.imread(image_path)
                return {"image_path": image_path, "image_width": im.shape[1], "image_height": im.shape[0],
                        "detections": [{"class_id": 0, "label": "person", "confidence": .9,
                                        "bbox": {"x1": 5, "y1": 5, "x2": 40, "y2": 40}}],
                        "object_count": 1, "inference_time_ms": 12.3, "annotated_image": im}
        mod = types.ModuleType("core.detection.detection_engine")
        mod.DetectionEngine = Engine
        return mod

    def run_app(self, page=None):
        if page is not None:
            self.h.state["page_navigation"] = page
        self.h.events.clear()
        self.h.downloads.clear()
        return runpy.run_path(str(MAIN), run_name="__main__")

    # file helpers
    def png_bytes(self, w=400, h=200):
        return cv2.imencode(".png", np.full((h, w, 3), 90, np.uint8))[1].tobytes()

    def video_bytes(self):
        p = self.tmp / "clip.mp4"
        w = cv2.VideoWriter(str(p), cv2.VideoWriter_fourcc(*"mp4v"), 10, (160, 120))
        if not w.isOpened():
            self.skipTest("MP4 encoding unavailable")
        for i in range(8):
            w.write(np.full((120, 160, 3), i * 9, np.uint8))
        w.release()
        return p.read_bytes()

    class Up:
        def __init__(self, name, data):
            self.name, self._d, self.size, self.file_id = name, data, len(data), "f1"
        def getvalue(self): return self._d
        def getbuffer(self): return memoryview(self._d)


class NavigationTests(AppCase):
    def test_fresh_launch_shows_command_center_and_sidebar_status(self):
        self.run_app()
        self.assertEqual(self.h.h1_titles(), ["Command Center"])
        html = self.h.sidebar_html()
        for needle in ("VISION", "General model", "Plate model", "Plate OCR", "Video playback", "Running: mainn2.py"):
            self.assertIn(needle, html)

    def test_every_page_reaches_its_renderer(self):
        for page in PAGES:
            self.run_app(page)
            self.assertEqual(self.h.h1_titles(), [page], page)

    def test_quick_actions_navigate_to_the_right_pages(self):
        for key, target in (("qa_image", "Vision Studio"), ("qa_plate", "License Plate Studio"),
                            ("qa_video", "Video Intelligence")):
            self.h.state.clear()
            self.run_app("Command Center")
            self.h.buttons[key] = True
            self.run_app("Command Center")   # click: callback runs, sets navigation_target
            self.h.buttons.clear()
            self.run_app()                   # next rerun applies it before the radio is created
            self.assertEqual(self.h.state["page_navigation"], target)
            self.assertEqual(self.h.h1_titles(), [target])

    def test_return_to_command_center(self):
        self.run_app("Analytics")
        self.run_app("Command Center")
        self.assertEqual(self.h.h1_titles(), ["Command Center"])

    def test_stale_page_value_does_not_break_the_app(self):
        self.h.state["page_navigation"] = "Removed Page"
        self.run_app()
        self.assertEqual(self.h.h1_titles(), ["Command Center"])

    def test_page_is_restored_from_query_params_after_refresh(self):
        self.h.query_params["page"] = "Analytics"
        self.run_app()
        self.assertEqual(self.h.h1_titles(), ["Analytics"])
        self.assertEqual(self.h.query_params["page"], "Analytics")

    def test_project_root_is_the_folder_containing_core(self):
        ns = self.run_app()
        self.assertEqual(ns["PROJECT_ROOT"], ROOT)

    def test_empty_analytics_and_command_center_states(self):
        self.run_app("Analytics")
        self.assertEqual(self.h.messages("plotly_chart"), [])  # no charts for an empty session
        self.run_app("Command Center")
        self.assertTrue(any("fresh session" in t for t in self.h.messages("markdown")))


class ImageAndVideoFlowTests(AppCase):
    def test_image_flow_runs_once_and_exports(self):
        self.h.uploads["image_upload_0"] = self.Up("pic.png", self.png_bytes())
        self.h.buttons["studio_run"] = True
        self.run_app("Vision Studio")
        self.assertIsNotNone(self.h.state["latest"])
        self.h.buttons.clear()
        n = len(self.h.state["history"])
        self.run_app("Vision Studio")
        self.assertEqual(len(self.h.state["history"]), n)
        labels = [d[0] for d in self.h.downloads]
        self.assertIn("Annotated image (PNG)", labels)
        self.assertIn("Detection table (CSV)", labels)

    def test_video_flow_command_center_regression_and_downloads(self):
        self.h.uploads["video_upload_0"] = self.Up("clip.mp4", self.video_bytes())
        self.run_app("Video Intelligence")
        self.assertIsNone(self.h.state["video_result"])  # no inference without the click
        self.h.buttons["video_analyze"] = True
        self.run_app("Video Intelligence")
        result = self.h.state["video_result"]
        self.assertIsNotNone(result)
        self.assertEqual((result["result"]["frames_read"], result["result"]["frames_processed"]), (8, 8))
        self.h.buttons.clear()
        n = len(self.h.state["history"])
        self.run_app("Video Intelligence")
        self.assertEqual(len(self.h.state["history"]), n)
        labels = [d[0] for d in self.h.downloads]
        self.assertTrue(any(l.startswith("Annotated video") for l in labels))
        self.assertIn("Detection report (CSV)", labels)
        # Regression: Command Center used to raise KeyError('processing_seconds') after a video run.
        self.run_app("Command Center")
        self.assertEqual(self.h.h1_titles(), ["Command Center"])
        self.run_app("Analytics")
        self.assertEqual(self.h.h1_titles(), ["Analytics"])
        self.state_cleanup()

    def state_cleanup(self):
        ns = runpy.run_path(str(MAIN), run_name="__main__")
        ns["reset_video"]()
        self.assertIsNone(self.h.state["video_result"])


class PlateStudioTests(AppCase):
    def _patch_service(self, ocr_behaviour=None):
        import license_plate_service as lps
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from test_license_plate_service import FakeBox, FakeModel, FakeOCR

        def from_weights(cls, path, ocr=None, loader=None):
            return cls(FakeModel([FakeBox(0, 0.9, [50, 50, 150, 90]), FakeBox(0, 0.7, [200, 100, 330, 150])]),
                       ocr=FakeOCR(ocr_behaviour), model_path=str(path))
        lps.LicensePlateService.from_weights = classmethod(from_weights)
        self._orig = from_weights

    def _weights(self):
        w = self.tmp / "plates.pt"
        w.write_bytes(b"weights")
        os.environ["VISIONFORGE_PLATE_MODEL"] = str(w)

    def test_no_model_state_is_truthful_and_run_is_disabled(self):
        os.environ["VISIONFORGE_PLATE_MODEL"] = str(self.tmp / "missing.pt")
        self.h.uploads["plate_upload_0"] = self.Up("car.png", self.png_bytes())
        self.h.buttons["plate_run"] = True
        self.run_app("License Plate Studio")
        self.assertEqual(self.h.h1_titles(), ["License Plate Studio"])
        self.assertIsNone(self.h.state["plate_latest"])      # disabled button cannot run
        self.assertEqual(self.h.state["history"], [])
        self.assertIn("No weights", " ".join(self.h.messages("markdown")))

    def test_full_plate_flow_with_ocr_and_exports(self):
        self._weights()
        import license_plate_service  # noqa: F401  (imported fresh by the app; patch after import)
        self.h.uploads["plate_upload_0"] = self.Up("car.png", self.png_bytes())
        self.h.buttons["plate_run"] = True
        # patch the module the app will import
        import importlib
        lps = importlib.import_module("license_plate_service")
        self._patch_service()
        self.run_app("License Plate Studio")
        latest = self.h.state["plate_latest"]
        self.assertIsNotNone(latest)
        self.assertEqual(latest["result"]["plate_count"], 2)
        self.assertEqual(self.h.state["history"][-1]["kind"], "plate")
        self.h.buttons.clear()
        n = len(self.h.state["history"])
        self.run_app("License Plate Studio")
        self.assertEqual(len(self.h.state["history"]), n)    # no re-inference on rerun
        labels = [d[0] for d in self.h.downloads]
        for expected in ("Annotated image (PNG)", "Results (CSV)", "Report (JSON)"):
            self.assertIn(expected, labels)
        self.run_app("Analytics")
        self.assertEqual(self.h.h1_titles(), ["Analytics"])
        self.run_app("Command Center")
        self.assertEqual(self.h.h1_titles(), ["Command Center"])

    def test_ocr_unavailable_state_still_shows_detections(self):
        self._weights()
        import importlib
        lps = importlib.import_module("license_plate_service")

        def boom(img):
            raise lps.OCRUnavailableError("EasyOCR is not installed. Install it with: pip install easyocr")
        self._patch_service(boom)
        self.h.uploads["plate_upload_0"] = self.Up("car.png", self.png_bytes())
        self.h.buttons["plate_run"] = True
        self.run_app("License Plate Studio")
        self.h.buttons.clear()
        self.run_app("License Plate Studio")
        self.assertEqual(self.h.state["plate_latest"]["result"]["plate_count"], 2)
        self.assertTrue(any("OCR unavailable" in t for t in self.h.messages("warning")))

    def test_plate_model_load_failure_is_reported_not_raised(self):
        self._weights()
        import importlib
        lps = importlib.import_module("license_plate_service")

        def failing(cls, path, ocr=None, loader=None):
            raise lps.PlateModelError("None of this model's 80 classes look like license plates (person, car…).")
        lps.LicensePlateService.from_weights = classmethod(failing)
        self.h.uploads["plate_upload_0"] = self.Up("car.png", self.png_bytes())
        self.h.buttons["plate_run"] = True
        self.run_app("License Plate Studio")
        self.assertIsNone(self.h.state["plate_latest"])
        self.assertTrue(any("plate model could not be used" in t for t in self.h.messages("error")))
        self.assertTrue(self.h.state["plate_error"])

    def test_corrupt_image_is_rejected_with_message(self):
        self._weights()
        self.h.uploads["plate_upload_0"] = self.Up("bad.png", b"not an image")
        self.run_app("License Plate Studio")
        self.assertTrue(any("could not be decoded" in t for t in self.h.messages("error")))


class PlatformTests(AppCase):
    def test_platform_overview_reports_measured_state(self):
        self.run_app("Platform Overview")
        self.assertEqual(self.h.h1_titles(), ["Platform Overview"])
        self.assertTrue(self.h.messages("dataframe") is not None)


if __name__ == "__main__":
    unittest.main()
