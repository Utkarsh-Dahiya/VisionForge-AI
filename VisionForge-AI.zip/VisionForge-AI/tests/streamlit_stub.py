"""A recording stand-in for `streamlit` + `plotly.express`, for logic-level app tests.

It does NOT render anything. It lets tests execute mainn2.py top to bottom and
observe which page renderer ran, which messages/downloads were produced, and how
session state changed. Real browser behaviour must be checked manually or with
streamlit.testing (see test_app_streamlit_apptest.py).
"""
import sys
import types


class D:
    """Universal dummy: any attribute/call/with-block/iteration works."""
    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return D()

    def __call__(self, *a, **k):
        return D()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def __iter__(self):
        return iter([D(), D()])


class State(dict):
    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError:
            raise AttributeError(k)

    def __setattr__(self, k, v):
        self[k] = v


class Harness:
    def __init__(self):
        self.state = State()
        self.query_params = {}
        self.uploads, self.buttons = {}, {}
        self.events, self.downloads = [], []
        self.module = self._build()

    # ------------------------------------------------------------ recording
    def _rec(self, name):
        def f(*a, **k):
            self.events.append((name, str(a[0]) if a else ""))
            return D()
        return f

    def _build(self):
        st = types.ModuleType("streamlit")
        st.__version__ = "1.50.0"
        st.session_state = self.state
        st.query_params = self.query_params
        st.sidebar = D()
        st.column_config = D()
        for n in ("set_page_config markdown caption write code info warning error success image video "
                  "dataframe plotly_chart empty divider text").split():
            setattr(st, n, self._rec(n))
        st.expander = lambda *a, **k: D()
        st.status = lambda *a, **k: D()
        st.progress = lambda *a, **k: D()
        st.columns = lambda spec, **k: [D() for _ in range(spec if isinstance(spec, int) else len(spec))]
        st.tabs = lambda labels: [D() for _ in labels]

        def button(label, key=None, disabled=False, on_click=None, args=(), **k):
            if self.buttons.get(key) and not disabled:
                if on_click:
                    on_click(*args)  # Streamlit runs callbacks before the rerun
                return True
            return False
        st.button = button

        def download_button(label, data, *a, **k):
            self.downloads.append((label, len(data) if data is not None else None))
            return False
        st.download_button = download_button

        def keyed(default_index):
            def f(label, *a, key=None, **k):
                value = a[default_index] if len(a) > default_index else k.get("value")
                if key is not None:
                    self.state.setdefault(key, value)
                    return self.state[key]
                return value
            return f
        st.slider = keyed(2)          # (label, min, max, value)
        st.number_input = keyed(2)    # (label, min, max, value)

        def text_input(label, value="", key=None, **k):
            if key is not None:
                self.state.setdefault(key, value)
                return self.state[key]
            return value
        st.text_input = text_input

        def checkbox(label, value=False, key=None, **k):
            if key is not None:
                self.state.setdefault(key, value)
                return self.state[key]
            return value
        st.checkbox = checkbox
        st.file_uploader = lambda label, type=None, key=None, **k: self.uploads.get(key)

        def radio(label, options, key=None, **k):
            self.state.setdefault(key, options[0])
            if self.state[key] not in options:
                raise ValueError(f"{self.state[key]!r} is not in radio options")  # real Streamlit raises too
            return self.state[key]
        st.radio = radio

        def cache_resource(*a, **k):
            def deco(fn):
                cache = {}
                def wrapped(*x):
                    if x not in cache:
                        cache[x] = fn(*x)
                    return cache[x]
                return wrapped
            return deco(a[0]) if a and callable(a[0]) else deco
        st.cache_resource = cache_resource
        return st

    # ------------------------------------------------------------ helpers
    def h1_titles(self):
        import re
        out = []
        for name, text in self.events:
            if name == "markdown":
                out += re.findall(r"<h1>(.*?)</h1>", text)
        return out

    def messages(self, kind):
        return [t for n, t in self.events if n == kind]

    def sidebar_html(self):
        return " ".join(t for n, t in self.events if n == "markdown" and "vf-sb" in t)


def install(harness):
    """Swap in the stubs; returns an undo function."""
    saved = {k: sys.modules.get(k) for k in ("streamlit", "plotly", "plotly.express", "components")}
    px = D()
    plotly = types.ModuleType("plotly")
    plotly.express = px
    sys.modules.update({"streamlit": harness.module, "plotly": plotly, "plotly.express": px})
    sys.modules.pop("components", None)  # must re-import against the stub

    def undo():
        for k, v in saved.items():
            if v is None:
                sys.modules.pop(k, None)
            else:
                sys.modules[k] = v
    return undo
