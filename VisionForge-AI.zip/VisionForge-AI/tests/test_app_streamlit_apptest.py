"""Navigation test against REAL Streamlit via streamlit.testing (AppTest).

Skipped automatically when Streamlit is not installed. It exercises the real widget
lifecycle (radio in the sidebar, reruns, session state) but still does not check
visual layout; for that, follow the manual steps in README.md.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _stubs  # noqa: F401,E402

try:
    from streamlit.testing.v1 import AppTest
except Exception:  # Streamlit missing or too old
    AppTest = None

MAIN = Path(__file__).resolve().parents[1] / "mainn2.py"
PAGES = ["Command Center", "Vision Studio", "License Plate Studio",
         "Video Intelligence", "Analytics", "Platform Overview"]


@unittest.skipIf(AppTest is None, "streamlit.testing is not available")
class RealStreamlitNavigation(unittest.TestCase):
    def test_sidebar_radio_opens_every_page(self):
        at = AppTest.from_file(str(MAIN), default_timeout=90).run()
        self.assertFalse(at.exception, at.exception)
        self.assertEqual(list(at.sidebar.radio(key="page_navigation").options), PAGES)
        for page in PAGES:
            at.sidebar.radio(key="page_navigation").set_value(page).run()
            self.assertFalse(at.exception, f"{page}: {at.exception}")
            self.assertTrue(any(f"<h1>{page}</h1>" in m.value for m in at.markdown), page)


if __name__ == "__main__":
    unittest.main()
