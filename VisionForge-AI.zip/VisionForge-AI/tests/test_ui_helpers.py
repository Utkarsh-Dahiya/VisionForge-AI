import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _stubs  # noqa: F401,E402
import cv2  # noqa: E402
import helpers  # noqa: E402


class HelperTests(unittest.TestCase):
    def test_decode_invalid_bytes(self):
        self.assertIsNone(helpers.decode_image(b"not an image"))
        self.assertIsNone(helpers.decode_image(b""))

    def test_decode_roundtrip(self):
        data = cv2.imencode(".png", np.zeros((20, 30, 3), np.uint8))[1].tobytes()
        self.assertEqual(helpers.decode_image(data).shape, (20, 30, 3))

    def test_temp_file_removed_on_success_and_error(self):
        img = np.zeros((8, 8, 3), np.uint8)
        with helpers.temporary_image_file(img) as p:
            self.assertTrue(p.exists())
        self.assertFalse(p.exists())
        with self.assertRaises(ValueError):
            with helpers.temporary_image_file(img) as p2:
                raise ValueError
        self.assertFalse(p2.exists())

    def test_detections_frame_empty_and_bbox(self):
        self.assertTrue(helpers.detections_to_frame([]).empty)
        d = [{"class_id": 0, "label": "person", "confidence": 0.9,
              "bbox": {"x1": 1, "y1": 2, "x2": 3, "y2": 4}}]
        f = helpers.detections_to_frame(d)
        self.assertEqual(list(f.columns), ["ID", "Object", "Confidence", "x1", "y1", "x2", "y2"])
        self.assertEqual(f.iloc[0][["x1", "y1", "x2", "y2"]].tolist(), [1, 2, 3, 4])
        plain = helpers.detections_to_frame([{"label": "a", "confidence": .5}])
        self.assertEqual(list(plain.columns), ["ID", "Object", "Confidence"])

    def test_image_summary_has_processing_seconds(self):
        rec = helpers.summarize_analysis("x.png", {"detections": [{"label": "cat", "confidence": 0.8}],
                                                    "object_count": 1, "inference_time_ms": 1500.0}, 0.25)
        self.assertEqual(rec["kind"], "image")
        self.assertAlmostEqual(rec["processing_seconds"], 1.5)

    def test_video_summary_keys_match_what_the_app_reads(self):
        """Regression: the Command Center read `processing_seconds`, which was missing."""
        result = {"total_detections": 2, "frames_read": 5, "frames_processed": 3,
                  "processing_time_seconds": 1.5, "video_width": 10, "video_height": 5,
                  "detections": [
                      {"frame": 0, "timestamp_seconds": 0.0, "class_id": 0, "label": "person",
                       "confidence": 0.8, "x1": 0, "y1": 0, "x2": 1, "y2": 1},
                      {"frame": 2, "timestamp_seconds": 0.2, "class_id": 0, "label": "person",
                       "confidence": 0.6, "x1": 0, "y1": 0, "x2": 1, "y2": 1}]}
        v = helpers.summarize_video("v.mp4", result, 0.25, 2, None)
        self.assertEqual((v["kind"], v["objects"], v["frames_processed"]), ("video", 2, 3))
        self.assertAlmostEqual(v["processing_seconds"], 1.5)
        self.assertAlmostEqual(v["mean_confidence"], 0.7)
        self.assertEqual(helpers.processing_label(v), "0:01")
        self.assertEqual(helpers.processing_label({"kind": "image", "inference_ms": 12.4}), "12 ms")
        per = helpers.detections_per_frame(helpers.video_records_frame(result))
        self.assertEqual(per["Detections"].tolist(), [1, 1])

    def test_history_frame_and_stamp(self):
        img = helpers.stamp(helpers.summarize_analysis("i.png", {"detections": [{"label": "a", "confidence": .5}],
                                                                  "object_count": 1}, 0.5))
        self.assertIn("completed_at", img)
        h = helpers.history_frame([img])
        self.assertEqual(h["Kind"].tolist(), ["image"])
        self.assertTrue(helpers.history_frame([]).empty)

    def test_formatters(self):
        self.assertEqual(helpers.format_bytes(512), "512 B")
        self.assertEqual(helpers.format_bytes(2048), "2.00 KB")
        self.assertEqual(helpers.format_seconds(None), "N/A")
        self.assertEqual(helpers.format_seconds(125), "2:05")

    def test_find_weights_missing(self):
        self.assertIsNone(helpers.find_weights(Path("/nonexistent"), "nope.pt"))


if __name__ == "__main__":
    unittest.main()
