import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _stubs  # noqa: F401,E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

import license_plate_service as lps  # noqa: E402


class FakeBox:
    def __init__(self, cls_id, conf, xyxy):
        self.cls = np.array([cls_id], dtype=np.float32)
        self.conf = np.array([conf], dtype=np.float32)
        self.xyxy = np.array([xyxy], dtype=np.float32)


class FakeResult:
    def __init__(self, boxes):
        self.boxes = boxes


class FakeModel:
    def __init__(self, boxes=(), names=None):
        self.boxes = list(boxes)
        self.names = names if names is not None else {0: "license_plate", 1: "car"}

    def predict(self, source, conf, verbose=False):
        return [FakeResult([b for b in self.boxes if float(b.conf[0]) >= conf])]


class FakeOCR:
    name = "FakeOCR"

    def __init__(self, behaviour=None):
        self.behaviour = behaviour or (lambda img: [([[0, 0], [10, 0], [10, 5], [0, 5]], "ab 12", 0.9)])
        self.calls = 0

    def read(self, image):
        self.calls += 1
        return self.behaviour(image)


def image(h=200, w=400):
    img = np.full((h, w, 3), 90, np.uint8)
    return img


def two_plates():
    return [FakeBox(0, 0.60, [50, 50, 150, 90]), FakeBox(0, 0.95, [200, 100, 330, 150])]


class GeometryTests(unittest.TestCase):
    def test_clamp_orders_and_clips(self):
        self.assertEqual(lps.clamp_box(150, 90, 50, 50, 400, 200), (50, 50, 150, 90))
        self.assertEqual(lps.clamp_box(-20, -10, 500, 300, 400, 200), (0, 0, 400, 200))

    def test_clamp_padding_stays_inside(self):
        x1, y1, x2, y2 = lps.clamp_box(0, 0, 100, 50, 120, 60, pad=0.5)
        self.assertGreaterEqual(x1, 0)
        self.assertLessEqual(x2, 120)
        self.assertLessEqual(y2, 60)

    def test_clamp_degenerate_and_outside(self):
        self.assertIsNone(lps.clamp_box(10, 10, 10, 50, 100, 100))
        self.assertIsNone(lps.clamp_box(500, 500, 600, 600, 100, 100))


class ModelValidationTests(unittest.TestCase):
    def test_plate_class_names_accepted(self):
        for names in ({0: "license_plate"}, {0: "License Plate"}, {0: "number-plate"}, {0: "plate"},
                      {0: "car", 1: "licence plate"}):
            ids, _ = lps.resolve_plate_class_ids(names)
            self.assertTrue(ids)

    def test_general_coco_model_is_rejected(self):
        coco = {i: n for i, n in enumerate(["person", "bicycle", "car", "motorcycle", "airplane", "bus"])}
        with self.assertRaises(lps.PlateModelError) as ctx:
            lps.resolve_plate_class_ids(coco)
        self.assertIn("general-purpose", str(ctx.exception))
        with self.assertRaises(lps.PlateModelError):
            lps.LicensePlateService(FakeModel(names=coco))

    def test_single_unnamed_class_accepted_with_warning(self):
        ids, warnings = lps.resolve_plate_class_ids({0: "object"})
        self.assertEqual(ids, [0])
        self.assertTrue(warnings)

    def test_no_names_rejected(self):
        with self.assertRaises(lps.PlateModelError):
            lps.resolve_plate_class_ids({})

    def test_file_status_and_from_weights_errors(self):
        tmp = Path(tempfile.mkdtemp())
        self.assertEqual(lps.plate_model_file_status(tmp / "none.pt")["state"], "missing")
        self.assertEqual(lps.plate_model_file_status(None)["state"], "missing")
        txt = tmp / "w.txt"
        txt.write_text("x")
        self.assertEqual(lps.plate_model_file_status(txt)["state"], "invalid")
        empty = tmp / "e.pt"
        empty.write_bytes(b"")
        self.assertEqual(lps.plate_model_file_status(empty)["state"], "invalid")
        with self.assertRaises(lps.PlateModelError):
            lps.LicensePlateService.from_weights(tmp / "none.pt")

    def test_from_weights_loader_failure_and_success(self):
        tmp = Path(tempfile.mkdtemp())
        w = tmp / "plates.pt"
        w.write_bytes(b"fake weights")

        def bad_loader(path):
            raise RuntimeError("corrupt")

        with self.assertRaises(lps.PlateModelError) as ctx:
            lps.LicensePlateService.from_weights(w, loader=bad_loader)
        self.assertIn("corrupt", str(ctx.exception))
        svc = lps.LicensePlateService.from_weights(w, loader=lambda p: FakeModel())
        self.assertEqual(svc.model_path, str(w))
        coco_loader = lambda p: FakeModel(names={0: "person", 1: "car"})  # noqa: E731
        with self.assertRaises(lps.PlateModelError):
            lps.LicensePlateService.from_weights(w, loader=coco_loader)

    def test_default_path_env_override(self):
        import os
        old = os.environ.get(lps.PLATE_MODEL_ENV)
        try:
            os.environ.pop(lps.PLATE_MODEL_ENV, None)
            self.assertEqual(lps.default_plate_model_path(Path("/proj")), Path("/proj/models/license_plate_detector.pt"))
            os.environ[lps.PLATE_MODEL_ENV] = "/x/best.pt"
            self.assertEqual(lps.default_plate_model_path(Path("/proj")), Path("/x/best.pt"))
        finally:
            os.environ.pop(lps.PLATE_MODEL_ENV, None)
            if old is not None:
                os.environ[lps.PLATE_MODEL_ENV] = old

    def test_ocr_status_is_truthful_when_missing(self):
        info = lps.ocr_dependency_status()
        import importlib.util
        self.assertEqual(info["installed"], importlib.util.find_spec("easyocr") is not None)

    @unittest.skipIf(__import__("importlib.util").util.find_spec("easyocr"), "EasyOCR is installed")
    def test_easyocr_backend_reports_missing_package(self):
        with self.assertRaises(lps.OCRUnavailableError) as ctx:
            lps.EasyOCRBackend().read(image())
        self.assertIn("pip install easyocr", str(ctx.exception))


class AnalyzeTests(unittest.TestCase):
    def service(self, boxes, ocr="default", names=None):
        ocr = FakeOCR() if ocr == "default" else ocr
        return lps.LicensePlateService(FakeModel(boxes, names), ocr=ocr, model_path="/m/plates.pt")

    def test_two_plates_sorted_by_confidence_with_ocr(self):
        r = self.service(two_plates()).analyze_image(image(), 0.25, run_ocr=True)
        self.assertEqual(r["plate_count"], 2)
        ds = r["detections"]
        self.assertEqual([d["plate_id"] for d in ds], [1, 2])
        self.assertGreater(ds[0]["detection_confidence"], ds[1]["detection_confidence"])
        self.assertEqual(ds[0]["plate_text"], "AB12")  # OCR segments carry no spaces
        self.assertEqual(ds[0]["ocr_status"], "ok")
        self.assertAlmostEqual(ds[0]["ocr_confidence"], 0.9)
        self.assertNotEqual(ds[0]["ocr_confidence"], ds[0]["detection_confidence"])
        self.assertEqual(r["annotated_image"].shape, image().shape)
        self.assertFalse(np.array_equal(r["annotated_image"], image()))

    def test_confidence_threshold_filters(self):
        r = self.service(two_plates()).analyze_image(image(), 0.8, run_ocr=False)
        self.assertEqual(r["plate_count"], 1)

    def test_non_plate_classes_ignored(self):
        boxes = [FakeBox(1, 0.99, [0, 0, 100, 100]), FakeBox(0, 0.9, [50, 50, 150, 90])]
        r = self.service(boxes).analyze_image(image(), 0.25, run_ocr=False)
        self.assertEqual(r["plate_count"], 1)
        self.assertEqual(r["detections"][0]["class_name"], "license_plate")

    def test_crops_are_clamped_to_image(self):
        boxes = [FakeBox(0, 0.9, [-30, -10, 60, 40]), FakeBox(0, 0.8, [350, 170, 500, 260])]
        r = self.service(boxes).analyze_image(image(200, 400), 0.25, run_ocr=False)
        self.assertEqual(r["plate_count"], 2)
        for d in r["detections"]:
            b = d["bbox"]
            self.assertTrue(0 <= b["x1"] < b["x2"] <= 400 and 0 <= b["y1"] < b["y2"] <= 200)
            self.assertGreater(d["crop"].size, 0)
            self.assertIn("Plate touches the image edge and may be cut off", d["warnings"])

    def test_degenerate_boxes_are_skipped_and_counted(self):
        boxes = [FakeBox(0, 0.9, [500, 500, 600, 600]), FakeBox(0, 0.9, [50, 50, 150, 90])]
        r = self.service(boxes).analyze_image(image(), 0.25, run_ocr=False)
        self.assertEqual((r["plate_count"], r["skipped_degenerate"]), (1, 1))

    def test_no_plates_is_a_clean_empty_result(self):
        ocr = FakeOCR()
        r = self.service([], ocr).analyze_image(image(), 0.25, run_ocr=True)
        self.assertEqual((r["plate_count"], r["detections"]), (0, []))
        self.assertEqual(ocr.calls, 0)
        self.assertIsNone(r["ocr_error"])

    def test_ocr_disabled_never_calls_backend(self):
        ocr = FakeOCR()
        r = self.service(two_plates(), ocr).analyze_image(image(), 0.25, run_ocr=False)
        self.assertEqual(ocr.calls, 0)
        self.assertTrue(all(d["ocr_status"] == "disabled" and d["plate_text"] == "" for d in r["detections"]))
        self.assertEqual(r["ocr_time_ms"], 0.0)

    def test_ocr_unavailable_keeps_detection_results(self):
        def boom(img):
            raise lps.OCRUnavailableError("EasyOCR is not installed. Install it with: pip install easyocr")
        ocr = FakeOCR(boom)
        r = self.service(two_plates(), ocr).analyze_image(image(), 0.25, run_ocr=True)
        self.assertEqual(r["plate_count"], 2)
        self.assertTrue(all(d["ocr_status"] == "unavailable" for d in r["detections"]))
        self.assertIn("pip install easyocr", r["ocr_error"])
        self.assertEqual(ocr.calls, 1)  # stops retrying once known unavailable

    def test_no_backend_configured(self):
        r = self.service(two_plates(), ocr=None).analyze_image(image(), 0.25, run_ocr=True)
        self.assertTrue(all(d["ocr_status"] == "unavailable" for d in r["detections"]))
        self.assertIsNotNone(r["ocr_error"])

    def test_one_plate_ocr_failure_does_not_lose_the_others(self):
        state = {"n": 0}

        def flaky(img):
            state["n"] += 1
            if state["n"] == 1:  # the first plate's OCR call fails
                raise ValueError("bad crop")
            return [([[0, 0], [10, 0], [10, 5], [0, 5]], "xy 9", 0.8)]

        r = self.service(two_plates(), FakeOCR(flaky)).analyze_image(image(), 0.25, run_ocr=True)
        statuses = [d["ocr_status"] for d in r["detections"]]
        self.assertEqual(statuses, ["error", "ok"])
        self.assertIn("OCR failed for this plate", r["detections"][0]["warnings"])
        self.assertIn("ValueError", r["detections"][0]["ocr_error"])

    def test_empty_ocr_text_and_low_confidence_warnings(self):
        r = self.service(two_plates(), FakeOCR(lambda img: [])).analyze_image(image(), 0.25, run_ocr=True)
        self.assertTrue(all(d["ocr_status"] == "no_text" for d in r["detections"]))
        self.assertTrue(all("No text recognised" in d["warnings"] for d in r["detections"]))
        low = FakeOCR(lambda img: [([[0, 0], [10, 0], [10, 5], [0, 5]], "Q1", 0.2)])
        r = self.service(two_plates(), low).analyze_image(image(), 0.25, run_ocr=True)
        self.assertIn("Low OCR confidence; verify the text", r["detections"][0]["warnings"])
        self.assertNotIn("Low detection confidence", r["detections"][1]["warnings"])  # 0.60 is above 0.50
        r2 = self.service([FakeBox(0, 0.30, [50, 50, 150, 90])]).analyze_image(image(), 0.25, run_ocr=False)
        self.assertIn("Low detection confidence", r2["detections"][0]["warnings"])

    def test_invalid_inputs(self):
        svc = self.service([])
        with self.assertRaises(ValueError):
            svc.analyze_image(np.zeros((10, 10), np.uint8))
        with self.assertRaises(ValueError):
            svc.analyze_image(image(), confidence=1.5)


class OCRTextTests(unittest.TestCase):
    def test_reading_order_two_lines(self):
        seg = [([[10, 40], [50, 40], [50, 60], [10, 60]], "1234", 0.8),
               ([[10, 5], [50, 5], [50, 25], [10, 25]], "mh12", 0.9),
               ([[60, 5], [100, 5], [100, 25], [60, 25]], "ab", 0.7)]
        out = lps.assemble_text(seg)
        self.assertEqual(out.text, "MH12 AB 1234")
        self.assertAlmostEqual(out.confidence, (0.8 + 0.9 + 0.7) / 3)

    def test_symbols_stripped_and_empty(self):
        self.assertEqual(lps.assemble_text([([[0, 0], [5, 0], [5, 5], [0, 5]], "a-b.", 0.5)]).text, "AB")
        out = lps.assemble_text([([[0, 0], [5, 0], [5, 5], [0, 5]], "--", 0.5)])
        self.assertEqual((out.text, out.confidence), ("", None))

    def test_preprocess_variants(self):
        small = np.full((20, 60, 3), 100, np.uint8)
        names = [n for n, _ in lps.preprocess_variants(small)]
        self.assertEqual(names, ["upscaled", "clahe"])
        self.assertGreaterEqual(lps.preprocess_variants(small)[0][1].shape[0], 80)


class ExportTests(unittest.TestCase):
    def result(self):
        svc = lps.LicensePlateService(FakeModel(two_plates()), ocr=FakeOCR(), model_path="/models/plates.pt")
        return svc.analyze_image(image(), 0.25, run_ocr=True)

    def test_rows_keep_original_ocr_and_separate_correction(self):
        res = self.result()
        rows = lps.plate_rows(res, "car.jpg", {1: "AB 99", 2: res["detections"][1]["plate_text"]})
        self.assertEqual(rows[0]["ocr_text"], "AB12")
        self.assertEqual(rows[0]["manual_correction"], "AB 99")
        self.assertEqual(rows[1]["manual_correction"], "")  # unchanged text is not a correction
        self.assertEqual(res["detections"][0]["plate_text"], "AB12")  # original result untouched

    def test_csv_roundtrip(self):
        res = self.result()
        csv = lps.rows_to_csv(lps.plate_rows(res, "car.jpg"))
        df = pd.read_csv(__import__("io").StringIO(csv))
        self.assertEqual(list(df.columns), lps.ROW_COLUMNS)
        self.assertEqual(len(df), 2)
        empty = lps.rows_to_csv([])
        self.assertEqual(empty.strip(), ",".join(lps.ROW_COLUMNS))

    def test_json_report_has_no_image_data_and_notes_confidences(self):
        res = self.result()
        report = json.loads(lps.build_json_report(res, "car.jpg", 0.25, {1: "ZZ"}))
        self.assertEqual(report["model"]["path_name"], "plates.pt")
        self.assertEqual(len(report["plates"]), 2)
        self.assertEqual(report["plates"][0]["manual_correction"], "ZZ")
        self.assertIn("not the detection confidence", report["note"])
        self.assertNotIn("crop", json.dumps(report))

    def test_summary_record(self):
        res = self.result()
        rec = lps.summarize_plate("car.jpg", res, 0.25)
        self.assertEqual((rec["kind"], rec["objects"], rec["ocr_read"], rec["ocr_failed"]), ("plate", 2, 2, 0))
        self.assertAlmostEqual(rec["mean_confidence"], (0.95 + 0.60) / 2, places=3)
        off = lps.summarize_plate("car.jpg", self.service_off(), 0.25)
        self.assertEqual((off["ocr_attempted"], off["ocr_read"], off["ocr_failed"]), (False, 0, 0))

    def service_off(self):
        svc = lps.LicensePlateService(FakeModel(two_plates()), ocr=FakeOCR())
        return svc.analyze_image(image(), 0.25, run_ocr=False)


if __name__ == "__main__":
    unittest.main()
