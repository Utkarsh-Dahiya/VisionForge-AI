# VisionForge AI

Local computer-vision platform: YOLO object detection on images and video, license plate detection with OCR,
and session analytics. Entry point: **`mainn2.py`**.

## Run (Windows PowerShell, from the project folder)

```powershell
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run mainn2.py
```

`yolo11n.pt` is looked up in the project folder, then `models\` and `weights\`.

## Pages

Command Center · Vision Studio · License Plate Studio · Video Intelligence · Analytics · Platform Overview.
Navigation is the menu in the left sidebar. The footer of the sidebar shows `Running: mainn2.py` so you can
confirm which file Streamlit is serving.

### If you only see the Command Center / no sidebar

1. Make sure `components.py`, `assets\neural.css` and `mainn2.py` are all from this delivery. An old
   `neural.css` contained a rule that hid the whole sidebar. The app now overrides that rule and shows
   "Stylesheet: Old neural.css (guarded)" in the sidebar status if it detects it.
2. Stop every running Streamlit window (Ctrl+C), then start one: `streamlit run mainn2.py`.
3. Hard-refresh the browser (Ctrl+F5). If the sidebar was collapsed, click the small arrow at the top left.

## License Plate Studio

Needs plate-trained weights that you supply: see `models\README.md`. OCR uses EasyOCR (`pip install easyocr`);
its model files download on first use (internet required once, roughly 100 MB). Without either, the page says
exactly what is missing and the rest of the app keeps working.

Detection confidence and OCR confidence are separate numbers. Manual corrections are stored apart from the OCR
text and exported in their own column.

## Tests

```powershell
python -m pytest -v
# without pytest, the new tests only:
python -m unittest discover -s tests -v
```

`tests\test_app_streamlit_apptest.py` uses Streamlit's own test runner and is skipped if unavailable.

## Manual verification (browser)

1. Launch, confirm the sidebar lists the six pages and the selected one is highlighted.
2. Click each page; each shows its title. On Command Center, the three quick-action buttons open their pages.
3. Vision Studio: upload an image, press *Run detection*, check the Annotated / Side by side / Original tabs and
   the PNG and CSV downloads.
4. Video Intelligence: upload a short MP4, press *Analyze video*, play the result, download MP4 and CSV.
5. License Plate Studio without weights: the model card says *No weights* and the run button is disabled.
   With weights: upload a vehicle photo, press *Detect & read plates*, check crops, OCR text, corrections, and the
   PNG / CSV / JSON downloads.
6. Analytics and Platform Overview reflect only what you ran.

## Debugging

Set `VISIONFORGE_DEBUG=1` before launching to show technical details on errors. Technical details are always
written to the terminal log.

## Privacy and network

All processing is local. The only network use is EasyOCR downloading its model files the first time OCR runs
(and Ultralytics fetching `yolo11n.pt` if it is missing locally). Uploaded images are held in memory; videos are
written to a temporary folder and removed when you press Reset, analyse another video, or exit.
