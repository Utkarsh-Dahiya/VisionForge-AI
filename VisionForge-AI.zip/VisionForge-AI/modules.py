"""Single source of truth for module status (Command Center + Platform Overview).

Statuses describe the code that exists and what has actually been verified:
  Implemented - working code path wired into the UI.
  Partial     - code exists but needs something you must supply (weights, packages).
  Planned     - no implementation yet.
Edit this file as the project evolves.
"""

APP_VERSION = "1.1.0"
APP_PHASE = "License Plate Studio"

IMPLEMENTED, PARTIAL, PLANNED = "Implemented", "Partial", "Planned"

MODULES = [
    {"icon": "◈", "name": "Vision Studio", "status": IMPLEMENTED,
     "desc": "Upload an image and run YOLO object detection.",
     "detail": "Single-image inference, annotated output, table with boxes, CSV export.",
     "target": "Vision Studio"},
    {"icon": "▶", "name": "Video Intelligence", "status": IMPLEMENTED,
     "desc": "Frame-by-frame YOLO detection on uploaded video.",
     "detail": "Annotated MP4 (H.264 when FFmpeg is available) and CSV. No identity tracking.",
     "target": "Video Intelligence"},
    {"icon": "⌗", "name": "License Plate Studio", "status": PARTIAL,
     "desc": "Plate detection plus OCR.",
     "detail": "Code complete, but needs plate-trained YOLO weights you supply; OCR needs EasyOCR.",
     "target": "License Plate Studio"},
    {"icon": "▥", "name": "Analytics", "status": PARTIAL,
     "desc": "Charts built from this session's analyses.",
     "detail": "Session-only; results are not persisted across reloads.",
     "target": "Analytics"},
    {"icon": "◎", "name": "Object tracking", "status": PLANNED,
     "desc": "Persistent object identities across frames.",
     "detail": "Not implemented. Video counts are detections, not unique objects.", "target": None},
    {"icon": "⬡", "name": "Safety / PPE", "status": PLANNED,
     "desc": "PPE checks and configurable safety rules.", "detail": "Not implemented.", "target": None},
    {"icon": "△", "name": "Fire & smoke", "status": PLANNED,
     "desc": "Fire and smoke detection.", "detail": "Not implemented.", "target": None},
    {"icon": "✎", "name": "General OCR Studio", "status": PLANNED,
     "desc": "Text extraction from arbitrary images.",
     "detail": "Not implemented (plate OCR lives inside License Plate Studio).", "target": None},
    {"icon": "▤", "name": "Persistent storage", "status": PLANNED,
     "desc": "Database-backed analysis history.", "detail": "Not implemented.", "target": None},
]

PAGES = ["Command Center", "Vision Studio", "License Plate Studio",
         "Video Intelligence", "Analytics", "Platform Overview"]
