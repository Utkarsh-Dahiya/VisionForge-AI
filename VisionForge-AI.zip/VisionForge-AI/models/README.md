# Plate detection model

License Plate Studio needs a **plate-trained YOLO model**. None is included here, and the general
`yolo11n.pt` is deliberately refused: its 80 COCO classes contain no license plate.

## Where to put it

Save your weights as `models/license_plate_detector.pt`, **or** set an environment variable, **or** type a
path under *Model settings* inside License Plate Studio:

```powershell
$env:VISIONFORGE_PLATE_MODEL = "C:\path\to\best.pt"
streamlit run mainn2.py
```

When the model loads, its class names are checked. At least one must look like a plate
(`license_plate`, `licence plate`, `number plate`, `plate`, `registration`, ...). A model with exactly one
class is accepted with a notice. Anything else is rejected with an explanation.

## Getting one

* **Train your own** with Ultralytics on a labelled plate dataset (check each dataset's license; Open Images has
  a "Vehicle registration plate" class, and Roboflow Universe and Kaggle host plate datasets):

  ```powershell
  yolo detect train data=plates.yaml model=yolo11n.pt epochs=50 imgsz=640
  ```

  The best weights are written to `runs\detect\train\weights\best.pt`.

  Example `plates.yaml`:

  ```yaml
  path: C:/path/to/dataset
  train: images/train
  val: images/val
  names:
    0: license_plate
  ```

* **Or use community weights.** Read the license and the training data's license before use, and verify the
  class names. Only load weights from sources you trust: `.pt` files are Python pickles and can execute code
  when loaded. This is why the app reads weights from a local path and does not accept uploaded model files.

Accuracy depends entirely on the training data. Test on images that resemble yours before relying on results.
