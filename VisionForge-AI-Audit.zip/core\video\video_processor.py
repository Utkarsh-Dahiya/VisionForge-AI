"""
VisionForge AI - Video Intelligence Engine.

Reads videos, performs YOLO object detection, generates an annotated
video, and exports frame-level detection records.
"""

from pathlib import Path
from time import perf_counter
from typing import Any, Callable

import cv2
import pandas as pd

from core.detection.detection_engine import DetectionEngine


CSV_COLUMNS = [
    "frame",
    "timestamp_seconds",
    "class_id",
    "label",
    "confidence",
    "x1",
    "y1",
    "x2",
    "y2",
]


class VideoProcessingError(RuntimeError):
    """Raised when video processing cannot be completed."""


class VideoProcessor:
    """Process videos using the existing VisionForge detection engine."""

    def __init__(
        self,
        detection_engine: DetectionEngine,
        output_dir: str | Path = "outputs/videos",
    ) -> None:
        self.detection_engine = detection_engine
        self.output_dir = Path(output_dir).resolve()
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def process_video(
        self,
        video_path: str | Path,
        confidence: float = 0.25,
        frame_stride: int = 1,
        max_frames: int | None = None,
        progress_callback: Callable[[int, int | None], None] | None = None,
    ) -> dict[str, Any]:
        """
        Process a video and generate an annotated MP4 and CSV report.

        Args:
            video_path: Source video path.
            confidence: Minimum confidence threshold, from 0 to 1.
            frame_stride: Run detection on every Nth frame.
            max_frames: Maximum source frames to read. None means all.
            progress_callback: Optional callback receiving (frames_read, total_frames).
                The total is None when the video metadata does not report a frame count.

        Frame numbering is zero-based. With frame_stride=2, detection
        runs on source frames 0, 2, 4, and so on. Skipped frames remain
        unannotated in the output video.

        Returns:
            Dictionary containing output paths, statistics, and records.
        """
        source_path = Path(video_path).resolve()

        if not source_path.is_file():
            raise FileNotFoundError(f"Video file not found: {source_path}")

        if not 0.0 <= confidence <= 1.0:
            raise ValueError("Confidence must be between 0.0 and 1.0.")

        if frame_stride < 1:
            raise ValueError("frame_stride must be at least 1.")

        if max_frames is not None and max_frames < 1:
            raise ValueError("max_frames must be at least 1 when specified.")

        capture = cv2.VideoCapture(str(source_path))

        if not capture.isOpened():
            capture.release()
            raise VideoProcessingError(f"Could not open video: {source_path}")

        writer = None

        output_path = (
            self.output_dir / f"{source_path.stem}_annotated.mp4"
        )
        csv_path = (
            self.output_dir / f"{source_path.stem}_detections.csv"
        )

        frames_read = 0
        frames_processed = 0
        records: list[dict[str, Any]] = []
        started_at = perf_counter()

        try:
            fps = float(capture.get(cv2.CAP_PROP_FPS))
            width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
            reported_frame_count = int(
                capture.get(cv2.CAP_PROP_FRAME_COUNT)
            )

            if width <= 0 or height <= 0:
                raise VideoProcessingError(
                    "The video has invalid frame dimensions."
                )

            if fps <= 0:
                fps = 25.0

            writer = cv2.VideoWriter(
                str(output_path),
                cv2.VideoWriter_fourcc(*"mp4v"),
                fps,
                (width, height),
            )

            if not writer.isOpened():
                raise VideoProcessingError(
                    "Could not initialize the MP4 video writer. "
                    "Check your OpenCV codec support."
                )

            while max_frames is None or frames_read < max_frames:
                success, frame = capture.read()

                if not success:
                    break

                frame_number = frames_read
                frames_read += 1

                if progress_callback is not None:
                    total_for_progress = (
                        max_frames if max_frames is not None
                        else reported_frame_count if reported_frame_count > 0
                        else None
                    )
                    if total_for_progress is not None:
                        total_for_progress = min(total_for_progress, reported_frame_count) if (
                            max_frames is not None and reported_frame_count > 0
                        ) else total_for_progress
                    progress_callback(frames_read, total_for_progress)

                if frame_number % frame_stride != 0:
                    writer.write(frame)
                    continue

                predictions = self.detection_engine.model.predict(
                    source=frame,
                    conf=confidence,
                    verbose=False,
                )

                if not predictions:
                    raise VideoProcessingError(
                        "The detection model returned no prediction result."
                    )

                prediction = predictions[0]
                annotated_frame = prediction.plot()

                if (
                    annotated_frame is None
                    or annotated_frame.shape[:2] != (height, width)
                ):
                    raise VideoProcessingError(
                        "The detection model returned an invalid "
                        "annotated frame."
                    )

                writer.write(annotated_frame)
                frames_processed += 1

                boxes = prediction.boxes

                if boxes is None:
                    continue

                for box in boxes:
                    class_id = int(box.cls.item())
                    names = self.detection_engine.model.names

                    label = names[class_id]
                    score = float(box.conf.item())

                    x1, y1, x2, y2 = (
                        int(value)
                        for value in box.xyxy[0].tolist()
                    )

                    records.append(
                        {
                            "frame": frame_number,
                            "timestamp_seconds": round(
                                frame_number / fps, 3
                            ),
                            "class_id": class_id,
                            "label": label,
                            "confidence": round(score, 4),
                            "x1": x1,
                            "y1": y1,
                            "x2": x2,
                            "y2": y2,
                        }
                    )

            if frames_read == 0:
                raise VideoProcessingError(
                    "No readable frames were found in the video."
                )

            if frames_processed == 0:
                raise VideoProcessingError(
                    "No video frames were processed."
                )

            # Release resources before checking the written video.
            writer.release()
            writer = None

            dataframe = pd.DataFrame(records, columns=CSV_COLUMNS)
            dataframe.to_csv(csv_path, index=False)

            if not output_path.is_file() or output_path.stat().st_size == 0:
                raise VideoProcessingError(
                    "The output video was not generated correctly."
                )

            # Verify that OpenCV can reopen the generated video.
            verification = cv2.VideoCapture(str(output_path))

            try:
                if not verification.isOpened():
                    raise VideoProcessingError(
                        "The generated output video cannot be reopened."
                    )

                success, first_frame = verification.read()

                if not success or first_frame is None:
                    raise VideoProcessingError(
                        "The generated output video contains no "
                        "readable frames."
                    )
            finally:
                verification.release()

            elapsed_seconds = perf_counter() - started_at

            return {
                "source_path": str(source_path),
                "output_video_path": str(output_path),
                "output_csv_path": str(csv_path),
                "video_fps": fps,
                "video_width": width,
                "video_height": height,
                "reported_frame_count": reported_frame_count,
                "frames_read": frames_read,
                "frames_processed": frames_processed,
                "total_detections": len(records),
                "unique_classes": sorted(
                    dataframe["label"].unique().tolist()
                ),
                "processing_time_seconds": round(elapsed_seconds, 3),
                "detections": records,
            }

        except Exception:
            if writer is not None:
                writer.release()

            output_path.unlink(missing_ok=True)
            csv_path.unlink(missing_ok=True)
            raise

        finally:
            capture.release()