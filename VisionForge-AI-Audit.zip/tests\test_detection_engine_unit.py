from pathlib import Path

import cv2
import numpy as np
import pytest

from core.detection.detection_engine import DetectionEngine


PROJECT_ROOT = Path(__file__).resolve().parents[1]
TEST_IMAGE = PROJECT_ROOT / "assets" / "test_image.jpg"


@pytest.fixture
def engine():
    """Create a detection engine for tests that require YOLO."""
    return DetectionEngine(
        model_path=str(PROJECT_ROOT / "yolo11n.pt")
    )


def test_missing_image_raises_file_not_found():
    """A nonexistent image should raise FileNotFoundError."""
    engine = DetectionEngine.__new__(DetectionEngine)

    missing_path = PROJECT_ROOT / "does_not_exist.jpg"

    with pytest.raises(FileNotFoundError):
        engine.detect_image(str(missing_path))


@pytest.mark.parametrize("confidence", [-0.1, 1.1])
def test_invalid_confidence_raises_value_error(confidence):
    """Confidence values outside 0–1 should be rejected."""
    engine = DetectionEngine.__new__(DetectionEngine)

    with pytest.raises(ValueError, match="Confidence"):
        engine.detect_image(
            image_path=str(TEST_IMAGE),
            confidence=confidence,
        )


def test_corrupted_image_raises_value_error(tmp_path):
    """A file that is not a valid image should be rejected."""
    corrupted_image = tmp_path / "corrupted.jpg"
    corrupted_image.write_text(
        "This is not a valid image",
        encoding="utf-8",
    )

    engine = DetectionEngine.__new__(DetectionEngine)

    with pytest.raises(ValueError, match="Could not read image"):
        engine.detect_image(str(corrupted_image))


def test_valid_image_returns_expected_result_structure(engine):
    """A real image should produce the expected result fields."""
    result = engine.detect_image(
        image_path=str(TEST_IMAGE),
        confidence=0.25,
    )

    assert result["image_width"] > 0
    assert result["image_height"] > 0
    assert result["object_count"] == len(result["detections"])
    assert result["inference_time_ms"] >= 0
    assert isinstance(result["annotated_image"], np.ndarray)

    assert result["annotated_image"].shape[:2] == (
        result["image_height"],
        result["image_width"],
    )

    assert isinstance(result["detections"], list)


def test_detection_records_have_valid_fields(engine):
    """Every returned detection should contain valid structured data."""
    result = engine.detect_image(
        image_path=str(TEST_IMAGE),
        confidence=0.25,
    )

    for detection in result["detections"]:
        assert isinstance(detection["class_id"], int)
        assert isinstance(detection["label"], str)
        assert detection["label"]
        assert 0 <= detection["confidence"] <= 1

        bbox = detection["bbox"]

        assert set(bbox) == {"x1", "y1", "x2", "y2"}

        assert 0 <= bbox["x1"] < bbox["x2"] <= result["image_width"]
        assert 0 <= bbox["y1"] < bbox["y2"] <= result["image_height"]


def test_test_image_exists():
    """The project's sample image should be available."""
    assert TEST_IMAGE.is_file()