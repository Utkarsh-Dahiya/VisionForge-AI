"""Single source of truth for module status (Command Center + Platform Overview).

Statuses are conservative: only what the UI code evidences is "Implemented".
Update this file as the project changes.
"""

APP_VERSION = "1.0.0"
APP_PHASE = "License Plate Studio"

IMPLEMENTED, PARTIAL, PLANNED = "Implemented", "Partial", "Planned"

MODULES = [
    {"icon": "◈", "name": "Vision Studio", "status": IMPLEMENTED,
     "desc": "Upload an image and run YOLO object detection.",
     "detail": "Single-image inference, annotated output, table and CSV export.",
     "target": "Vision Studio"},
    {"icon": "⌗", "name": "License Plate Studio", "status": PARTIAL,
     "desc": "Plate-specific detection and OCR.",
     "detail": "Requires custom plate-trained YOLO weights; OCR uses EasyOCR.",
     "target": "License Plate Studio"},
    {"icon": "▥", "name": "Analytics", "status": PARTIAL,
     "desc": "Charts built from this session's detections.",
     "detail": "Session-only; results are not persisted across reloads.",
     "target": "Analytics"},
    {"icon": "⌁", "name": "Video Intelligence", "status": PARTIAL,
     "desc": "Frame-by-frame video analysis.", "detail": "Video processing module available; UI integration needs verification.", "target": "Video Intelligence"},
    {"icon": "⬡", "name": "Safety / PPE", "status": PLANNED,
     "desc": "PPE checks and configurable safety rules.", "detail": "Not started.", "target": None},
    {"icon": "◎", "name": "Tracking & Events", "status": PLANNED,
     "desc": "Object tracking and event detection.", "detail": "Not started.", "target": None},
    {"icon": "⌗", "name": "OCR Studio", "status": PLANNED,
     "desc": "Text extraction from images.", "detail": "Not started.", "target": None},
    {"icon": "▤", "name": "Persistent storage", "status": PLANNED,
     "desc": "Database-backed analysis history.", "detail": "Not started.", "target": None},
    {"icon": "✦", "name": "AI reporting", "status": PLANNED,
     "desc": "Generated analysis reports.", "detail": "Not started.", "target": None},
]

PAGES = ["Command Center", "Vision Studio", "License Plate Studio", "Video Intelligence", "Analytics", "Platform Overview"]
