"""video_service.analyze_video tests: backward compatibility and tracking-option forwarding.

Run from the project root (``python -m pytest``) so ``video_service`` is importable.
"""
from pathlib import Path

import cv2
import numpy as np
import pytest

import video_service as vs
from core.video.video_processor import VideoProcessor

BOX = (50, 60, 150, 160)


class _Box:
    def __init__(self):
        self.cls = np.array([0], dtype=np.float32)
        self.conf = np.array([0.9], dtype=np.float32)
        self.xyxy = np.array([BOX], dtype=np.float32)


class _Boxes:
    def __init__(self, track_id):
        self._box = _Box()
        self.id = None if track_id is None else _Ids([track_id])

    def __iter__(self):
        yield self._box


class _Ids(list):
    def tolist(self):
        return list(self)


class _Prediction:
    def __init__(self, frame, boxes):
        self.frame, self.boxes = frame, boxes

    def plot(self):
        return self.frame.copy()


class Model:
    """Tracking-capable fake that records how it was called."""

    names = {0: "person"}

    def __init__(self, track_id=1):
        self.track_id = track_id
        self.track_calls, self.predict_calls = [], []
        self.predictor = None

    def track(self, source, conf, persist, tracker, verbose=False, **extra):
        self.track_calls.append({"persist": persist, "tracker": tracker, "extra": extra})
        return [_Prediction(source, _Boxes(self.track_id))]

    def predict(self, source, conf, verbose=False, **extra):
        self.predict_calls.append({"extra": extra})
        return [_Prediction(source, _Boxes(None))]


class Engine:
    def __init__(self, model):
        self.model = model


@pytest.fixture
def video(tmp_path):
    path = tmp_path / "input.mp4"
    writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), 10, (320, 240))
    if not writer.isOpened():
        pytest.skip("MP4 encoding is unavailable in this environment.")
    for _ in range(5):
        writer.write(np.zeros((240, 320, 3), dtype=np.uint8))
    writer.release()
    return path


def test_call_style_used_by_the_streamlit_page_still_works(tmp_path, video):
    """mainn2.py passes six positional arguments plus progress_callback."""
    progress = []
    result = vs.analyze_video(Engine(Model()), video, tmp_path / "runs", 0.25, 1, None,
                              progress_callback=lambda read, total: progress.append(read))

    assert progress and progress[-1] == 5
    assert Path(result["run_dir"]).is_dir()
    assert Path(result["output_video_path"]).parent == Path(result["run_dir"]).resolve()
    assert result["frames_read"] == 5 and result["total_detections"] == 5
    assert result["tracking_enabled"] is True and result["unique_tracks"] == 1
    assert result["playback_path"] is None or Path(result["playback_path"]).is_file()
    assert result["throughput_fps"] is None or result["throughput_fps"] > 0
    for key in ("wall_seconds", "transcode_seconds", "playback_note"):
        assert key in result


def test_tracking_options_are_forwarded_to_the_processor(tmp_path, video):
    model = Model()
    vs.analyze_video(Engine(model), video, tmp_path / "runs", 0.3, 1, None, transcode=False,
                     tracker="custom.yaml", iou=0.4, min_track_observations=2)
    assert model.track_calls[0]["tracker"] == "custom.yaml"
    assert model.track_calls[0]["extra"] == {"iou": 0.4}


def test_tracking_can_be_switched_off_through_the_service(tmp_path, video):
    model = Model()
    result = vs.analyze_video(Engine(model), video, tmp_path / "runs", 0.3, 1, None,
                              transcode=False, enable_tracking=False)
    assert not model.track_calls and model.predict_calls
    assert result["tracking_enabled"] is False


def test_each_run_gets_its_own_folder_and_its_own_records(tmp_path, video):
    root = tmp_path / "runs"
    first = vs.analyze_video(Engine(Model(track_id=1)), video, root, 0.3, 1, None, transcode=False)
    second = vs.analyze_video(Engine(Model(track_id=2)), video, root, 0.3, 1, None, transcode=False)
    assert first["run_dir"] != second["run_dir"]
    assert {d["track_id"] for d in first["detections"]} == {1}
    assert {d["track_id"] for d in second["detections"]} == {2}


def test_frame_estimate_matches_what_the_processor_actually_does(tmp_path, video):
    meta = vs.probe_video(video)
    for stride, max_frames in [(1, None), (2, None), (2, 4), (3, 5)]:
        expected = vs.estimate_frames(meta, stride, max_frames)
        result = vs.analyze_video(Engine(Model()), video, tmp_path / "runs", 0.3, stride,
                                  max_frames, transcode=False)
        assert expected == (result["frames_read"], result["frames_processed"])


def test_failed_run_leaves_no_run_folder_behind(tmp_path):
    root = tmp_path / "runs"
    with pytest.raises(FileNotFoundError):
        vs.analyze_video(Engine(Model()), tmp_path / "missing.mp4", root, 0.3, 1, None, transcode=False)
    assert not root.exists() or list(root.iterdir()) == []


def test_invalid_tracking_option_fails_cleanly(tmp_path, video):
    root = tmp_path / "runs"
    with pytest.raises(ValueError):
        vs.analyze_video(Engine(Model()), video, root, 0.3, 1, None, transcode=False, iou=2.0)
    assert not root.exists() or list(root.iterdir()) == []


def test_service_still_wraps_the_single_existing_processor():
    """Guard against accidentally introducing a second pipeline."""
    import inspect

    assert "VideoProcessor" in inspect.getsource(vs.analyze_video)
    assert VideoProcessor.process_video.__name__ == "process_video"
